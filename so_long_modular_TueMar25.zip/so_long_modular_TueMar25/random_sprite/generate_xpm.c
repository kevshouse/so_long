/* 
	Generates random colored spots on a background
	Usage:
 		./generate_xpm -w 800 -h 600 -s 20 -o output.xpm -t

	Control image dimensions with -w and -h
	Set number of spots with -s
	Specify output filename with -o
	Transparent background with -t
	Spots are randomly positioned and sized
	Colors are randomly generated
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef struct
{
    int x;
    int y;
    int radius;
    char color;
    unsigned char r, g, b;
} Spot;

void generate_xpm(int width, int height, int num_spots, const char *filename, int transparent) {
    int max_colors = num_spots + 1;
    if (max_colors > 94)
    {
        fprintf(stderr, "Error: Maximum number of spots is 93\n");
        exit(EXIT_FAILURE);
    }

    char **image = malloc(height * sizeof(char *));
    for (int i = 0; i < height; i++)
    {
        image[i] = malloc(width + 1);
        memset(image[i], 'a', width);
        image[i][width] = '\0';
    }

    Spot *spots = malloc(num_spots * sizeof(Spot));
    srand(time(NULL));

    for (int i = 0; i < num_spots; i++)
    {
        spots[i].x = rand() % width;
        spots[i].y = rand() % height;
        int min_r = 5;
        int max_r = (width < height ? width : height) / 4;
        spots[i].radius = min_r + rand() % (max_r - min_r + 1);
        spots[i].color = 'b' + i;
        spots[i].r = rand() % 256;
        spots[i].g = rand() % 256;
        spots[i].b = rand() % 256;
    }

    for (int s = 0; s < num_spots; s++) 
    {
        Spot *spot = &spots[s];
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                int dx = x - spot->x;
                int dy = y - spot->y;
                if (dx*dx + dy*dy < spot->radius*spot->radius) 
                {
                    image[y][x] = spot->color;
                }
            }
        }
    }

    FILE *fp = fopen(filename, "w");
    if (!fp) 
    {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    fprintf(fp, "/* XPM */\nstatic char *image[] = {\n");
    fprintf(fp, "\"%d %d %d 1\",\n", width, height, max_colors);
    
    if (transparent)
    {
        fprintf(fp, "\"a c None\",\n");
    } else {
        unsigned char bg_r = rand() % 256;
        unsigned char bg_g = rand() % 256;
        unsigned char bg_b = rand() % 256;
        fprintf(fp, "\"a c #%02X%02X%02X\",\n", bg_r, bg_g, bg_b);
    }

    for (int i = 0; i < num_spots; i++)
    {
        fprintf(fp, "\"%c c #%02X%02X%02X\",\n", 
                spots[i].color, spots[i].r, spots[i].g, spots[i].b);
    }

    for (int i = 0; i < height; i++) {
        fprintf(fp, "\"%s\"%s\n", image[i], i == height-1 ? "" : ",");
    }

    fprintf(fp, "};\n");
    fclose(fp);

    for (int i = 0; i < height; i++) free(image[i]);
    free(image);
    free(spots);
}

int main(int argc, char *argv[])
{
    int width = 100, height = 100, num_spots = 5, transparent = 0;
    char *filename = "output.xpm";
    int opt;

    while ((opt = getopt(argc, argv, "w:h:s:o:t")) != -1)
    {
        switch (opt) {
            case 'w': width = atoi(optarg); break;
            case 'h': height = atoi(optarg); break;
            case 's': num_spots = atoi(optarg); break;
            case 'o': filename = optarg; break;
            case 't': transparent = 1; break;
            default:
                fprintf(stderr, "Usage: %s [-w width] [-h height] [-s spots] [-o output] [-t]\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }

    generate_xpm(width, height, num_spots, filename, transparent);
    printf("Generated %s\n", filename);
    return 0;
}
