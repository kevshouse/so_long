/*
	Group-based color biasing with -g option (up to 5 groups)
	Colors in each group vary around a unique base color
	Simulated blending through color averaging
	Overlapping spots create mixed colors
	Groups get equal distribution of spots
	Base colors are guaranteed to be unique
	Color variation range controlled by COLOR_VARIATION constant

Usage:
	./program -w 800 -h 600 -s 50 -o groups.xpm -t -g 3

*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAX_GROUPS 5
#define COLOR_VARIATION 40

typedef struct {
    int x;
    int y;
    int radius;
    char color;
    unsigned char r, g, b;
    int group;
} Spot;

typedef struct {
    unsigned char base_r, base_g, base_b;
    int spot_count;
} Group;

unsigned char clamp(int value) {
    return (value < 0) ? 0 : (value > 255) ? 255 : value;
}

void generate_xpm(int width, int height, int num_spots, const char *filename, 
                 int transparent, int num_groups) {
    if (num_groups > MAX_GROUPS) num_groups = MAX_GROUPS;
    int max_colors = num_spots + 1;
    
    Group groups[MAX_GROUPS];
    srand(time(NULL));
    
    // Generate unique base colors for groups
    for (int g = 0; g < num_groups; g++) {
        int unique;
        do {
            unique = 1;
            groups[g].base_r = rand() % 256;
            groups[g].base_g = rand() % 256;
            groups[g].base_b = rand() % 256;
            
            // Ensure unique base colors
            for (int prev = 0; prev < g; prev++) {
                if (groups[g].base_r == groups[prev].base_r &&
                    groups[g].base_g == groups[prev].base_g &&
                    groups[g].base_b == groups[prev].base_b) {
                    unique = 0;
                    break;
                }
            }
        } while (!unique);
        
        groups[g].spot_count = num_spots / num_groups;
        if (g < num_spots % num_groups) groups[g].spot_count++;
    }

    // Setup image matrix
    unsigned char (*image)[width][3] = calloc(height, sizeof(*image));
    int (*counts)[width] = calloc(height, sizeof(*counts));

    Spot *spots = malloc(num_spots * sizeof(Spot));
    int spot_idx = 0;
    
    // Generate spots with group-based colors
    for (int g = 0; g < num_groups; g++) {
        for (int i = 0; i < groups[g].spot_count; i++) {
            Spot *spot = &spots[spot_idx++];
            spot->x = rand() % width;
            spot->y = rand() % height;
            spot->radius = 10 + rand() % (width/4);
            spot->group = g;
            
            // Generate color variation (fixed parentheses)
            spot->r = clamp(groups[g].base_r + (rand() % (COLOR_VARIATION*2) - COLOR_VARIATION));
            spot->g = clamp(groups[g].base_g + (rand() % (COLOR_VARIATION*2) - COLOR_VARIATION));
            spot->b = clamp(groups[g].base_b + (rand() % (COLOR_VARIATION*2) - COLOR_VARIATION));
        }
    }

    // Draw spots with color blending
    for (int s = 0; s < num_spots; s++) {
        Spot *spot = &spots[s];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int dx = x - spot->x;
                int dy = y - spot->y;
                if (dx*dx + dy*dy < spot->radius*spot->radius) {
                    // Blend colors by averaging
                    image[y][x][0] = (image[y][x][0] * counts[y][x] + spot->r) / (counts[y][x] + 1);
                    image[y][x][1] = (image[y][x][1] * counts[y][x] + spot->g) / (counts[y][x] + 1);
                    image[y][x][2] = (image[y][x][2] * counts[y][x] + spot->b) / (counts[y][x] + 1);
                    counts[y][x]++;
                }
            }
        }
    }

    // Create color map
    char *colormap = malloc(max_colors * 16);
    char *colptr = colormap;
    
    FILE *fp = fopen(filename, "w");
    fprintf(fp, "/* XPM */\nstatic char *image[] = {\n");
    fprintf(fp, "\"%d %d %d 1\",\n", width, height, max_colors);
    
    // Background
    if (transparent) {
        fprintf(fp, "\"a c None\",\n");
    } else {
        fprintf(fp, "\"a c #%02X%02X%02X\",\n", 
                rand()%256, rand()%256, rand()%256);
    }

    // Spot colors
    for (int i = 0; i < num_spots; i++) {
        fprintf(fp, "\"%c c #%02X%02X%02X\",\n", 
                'b' + i, spots[i].r, spots[i].g, spots[i].b);
    }

    // Pixel data
    for (int y = 0; y < height; y++) {
        fputc('"', fp);
        for (int x = 0; x < width; x++) {
            fputc(counts[y][x] > 0 ? 'b' + (y + x) % num_spots : 'a', fp);
        }
        fprintf(fp, "\"%s\n", y == height-1 ? "" : ",");
    }

    fprintf(fp, "};\n");
    fclose(fp);

    free(image);
    free(counts);
    free(spots);
    free(colormap);
}

int main(int argc, char *argv[]) {
    int width = 100, height = 100, num_spots = 5, transparent = 0, groups = 1;
    char *filename = "output.xpm";
    int opt;

    while ((opt = getopt(argc, argv, "w:h:s:o:tg:")) != -1) {
        switch (opt) {
            case 'w': width = atoi(optarg); break;
            case 'h': height = atoi(optarg); break;
            case 's': num_spots = atoi(optarg); break;
            case 'o': filename = optarg; break;
            case 't': transparent = 1; break;
            case 'g': groups = atoi(optarg); break;
            default:
                fprintf(stderr, "Usage: %s [-w width] [-h height] [-s spots] [-o output] [-t] [-g groups]\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }

    generate_xpm(width, height, num_spots, filename, transparent, groups);
    printf("Generated %s with %d color groups\n", filename, groups);
    return 0;
}
