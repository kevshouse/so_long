/*
	Group-based color biasing with -g option (up to 5 groups)
	Colors in each group vary around a unique base color
	Simulated blending through color averaging
	Overlapping spots create mixed colors
	Groups get equal distribution of spots
	Base colors are guaranteed to be unique
	Color variation range controlled by COLOR_VARIATION constant

Usage:
	./program -w 800 -h 600 -s 50 -o groups.xpm -t -g 3

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAX_GROUPS 5
#define COLOR_VARIATION 40
#define MAX_COLORS 92

const char SYMBOLS[] = "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~";

typedef struct {
    int x;
    int y;
    int radius;
    unsigned char r, g, b;
    int group;
} Spot;

typedef struct {
    unsigned char base_r, base_g, base_b;
    int spot_count;
} Group;

typedef struct {
    unsigned char r, g, b;
    char symbol;
} ColorEntry;

unsigned char clamp(int value) {
    return (value < 0) ? 0 : (value > 255) ? 255 : value;
}

void generate_xpm(int width, int height, int num_spots, const char *filename, 
                 int transparent, int num_groups) {
    if (width <= 0 || height <= 0) {
        fprintf(stderr, "Invalid dimensions: %dx%d\n", width, height);
        exit(EXIT_FAILURE);
    }

    Group groups[MAX_GROUPS];
    ColorEntry *colors = calloc(MAX_COLORS, sizeof(ColorEntry));
    int color_count = 0;
    srand(time(NULL));

    // Initialize background
    colors[0].symbol = SYMBOLS[0];
    color_count++;

    // Create groups
    for (int g = 0; g < num_groups; g++) {
        int unique;
        do {
            unique = 1;
            groups[g].base_r = rand() % 256;
            groups[g].base_g = rand() % 256;
            groups[g].base_b = rand() % 256;
            
            for (int prev = 0; prev < g; prev++) {
                if (groups[g].base_r == groups[prev].base_r &&
                    groups[g].base_g == groups[prev].base_g &&
                    groups[g].base_b == groups[prev].base_b) {
                    unique = 0;
                    break;
                }
            }
        } while (!unique);
        
        groups[g].spot_count = num_spots / num_groups;
        if (g < num_spots % num_groups) groups[g].spot_count++;
    }

    // Create spots
    Spot *spots = malloc(num_spots * sizeof(Spot));
    int spot_idx = 0;
    for (int g = 0; g < num_groups; g++) {
        for (int i = 0; i < groups[g].spot_count; i++) {
            if (spot_idx >= num_spots) break;
            
            Spot *spot = &spots[spot_idx++];
            spot->x = rand() % width;
            spot->y = rand() % height;
            spot->radius = 10 + rand() % (width/4);
            spot->group = g;
            
            spot->r = clamp(groups[g].base_r + (rand() % (COLOR_VARIATION*2) - COLOR_VARIATION));
            spot->g = clamp(groups[g].base_g + (rand() % (COLOR_VARIATION*2) - COLOR_VARIATION));
            spot->b = clamp(groups[g].base_b + (rand() % (COLOR_VARIATION*2) - COLOR_VARIATION));
        }
    }

    // Create image buffers
    unsigned char (*image)[width][3] = calloc(height, sizeof(*image));
    int (*blend_count)[width] = calloc(height, sizeof(*blend_count));

    // Draw spots
    for (int s = 0; s < num_spots; s++) {
        Spot *spot = &spots[s];
        int min_y = spot->y - spot->radius;
        int max_y = spot->y + spot->radius;
        int min_x = spot->x - spot->radius;
        int max_x = spot->x + spot->radius;
        
        for (int y = (min_y < 0 ? 0 : min_y); y < (max_y > height ? height : max_y); y++) {
            for (int x = (min_x < 0 ? 0 : min_x); x < (max_x > width ? width : max_x); x++) {
                int dx = x - spot->x;
                int dy = y - spot->y;
                if (dx*dx + dy*dy < spot->radius*spot->radius) {
                    image[y][x][0] += spot->r;
                    image[y][x][1] += spot->g;
                    image[y][x][2] += spot->b;
                    blend_count[y][x]++;
                }
            }
        }
    }

    // Build color map
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            if (blend_count[y][x] > 0) {
                unsigned char r = image[y][x][0] / blend_count[y][x];
                unsigned char g = image[y][x][1] / blend_count[y][x];
                unsigned char b = image[y][x][2] / blend_count[y][x];

                int found = 0;
                for (int i = 0; i < color_count; i++) {
                    if (colors[i].r == r && colors[i].g == g && colors[i].b == b) {
                        found = 1;
                        break;
                    }
                }

                if (!found && color_count < MAX_COLORS) {
                    colors[color_count].r = r;
                    colors[color_count].g = g;
                    colors[color_count].b = b;
                    colors[color_count].symbol = SYMBOLS[color_count];
                    color_count++;
                }
            }
        }
    }

    // Write XPM file
    FILE *fp = fopen(filename, "w");
    fprintf(fp, "/* XPM */\nstatic char *xpm[] = {\n");
    fprintf(fp, "\"%d %d %d 1\",\n", width, height, color_count);

    // Write color definitions
    for (int i = 0; i < color_count; i++) {
        if (i == 0 && transparent) {
            fprintf(fp, "\"%c c None\"", colors[i].symbol);
        } else {
            fprintf(fp, "\"%c c #%02X%02X%02X\"", 
                    colors[i].symbol, colors[i].r, colors[i].g, colors[i].b);
        }
        if (i < color_count - 1) fprintf(fp, ",\n");
        else fprintf(fp, "\n");
    }

    // Write pixel data with exact dimensions
    for (int y = 0; y < height; y++) {
        fputc('"', fp);
        for (int x = 0; x < width; x++) {
            if (blend_count[y][x] == 0) {
                fputc(colors[0].symbol, fp);
            } else {
                unsigned char r = image[y][x][0] / blend_count[y][x];
                unsigned char g = image[y][x][1] / blend_count[y][x];
                unsigned char b = image[y][x][2] / blend_count[y][x];
                
                char symbol = colors[0].symbol;
                for (int i = 1; i < color_count; i++) {
                    if (colors[i].r == r && colors[i].g == g && colors[i].b == b) {
                        symbol = colors[i].symbol;
                        break;
                    }
                }
                fputc(symbol, fp);
            }
        }
        fputc('"', fp);
        if (y < height - 1) fputc(',', fp);
        fputc('\n', fp);
    }

    fprintf(fp, "};\n");
    fclose(fp);

    // Cleanup
    free(image);
    free(blend_count);
    free(spots);
    free(colors);
}

int main(int argc, char *argv[]) {
    int width = 800, height = 600, num_spots = 20, transparent = 0, num_groups = 1;
    char *filename = "output.xpm";
    int opt;

    while ((opt = getopt(argc, argv, "w:h:s:o:tg:")) != -1) {
        switch (opt) {
            case 'w': width = atoi(optarg); break;
            case 'h': height = atoi(optarg); break;
            case 's': num_spots = atoi(optarg); break;
            case 'o': filename = optarg; break;
            case 't': transparent = 1; break;
            case 'g': num_groups = atoi(optarg); break;
            default:
                fprintf(stderr, "Usage: %s [-w width] [-h height] [-s spots] [-o filename] [-t] [-g groups]\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }

    generate_xpm(width, height, num_spots, filename, transparent, num_groups);
    printf("Valid XPM created: %s (%dx%d)\n", filename, width, height);
    return 0;
}
