#!/bin/sh
for i in $(seq -w 1 15); do
    ./gen_col_blob -w 32 -h 32 -s 5 -g 2 -o output_$i.xpm
done
