#!/bin/sh
find . -name '*.h' -exec cat {} + > all_headers_sources.txt
find . -name '*.c' -exec cat {} + >> all_headers_sources.txt
valgrind --leak-check=full --track-origins=yes --show-leak-kinds=all ./so_long > valgOP.txt 2>&1

