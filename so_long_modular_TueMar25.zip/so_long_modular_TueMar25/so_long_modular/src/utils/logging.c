#include "../includes/so_long.h"
#include <stdio.h>
#include <time.h>

void log_message(const char *message)
{
    FILE *log_file = fopen("debug.log", "a");
    if (log_file)
    {
        time_t now = time(NULL);
        fprintf(log_file, "[%s] %s\n", ctime(&now), message);
        fclose(log_file);
    }
    else
    {
        fprintf(stderr, "Could not open log file for writing.\n");
    }
}
