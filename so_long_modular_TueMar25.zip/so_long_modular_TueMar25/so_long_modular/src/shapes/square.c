//#include "mlx.h"
#include "../includes/so_long.h"

void draw_line(t_game *game, int x0, int y0, int x1, int y1, int color)
{
	int dx = abs(x1 - x0);
	int dy = -abs(y1 - y0);
	int sx = x0 < x1 ? 1 : -1;
	int sy = y0 < y1 ? 1 : -1;
	int err = dx + dy;
    
	while (1) 
	{
		mlx_pixel_put(game->mlx, game->win, x0, y0, color);
		if (x0 == x1 && y0 == y1) break;
		int e2 = 2 * err;
		if (e2 >= dy) 
		{
			err += dy;
			x0 += sx;
		}
		if (e2 <= dx) 
		{
			err += dx;
			y0 += sy;
		}
	}
}

t_square create_square(t_point tl, t_point tr, t_point br, t_point bl, int color)
{
	t_square square;

	square.tl = tl;
	square.tr = tr;
	square.br = br;
	square.bl = bl;
	square.color = color; // Set the color
	return (square);
}

void draw_square(t_game *game, t_square *square, int color)
{
	printf("Drawing square at coords: (%d, %d)\n", 
		square->tl.x, square->tl.y);
	if (square->tl.x < 0 || square->tl.y < 0 
		|| square->br.x > WINDOW_WIDTH 
		|| square->br.y > WINDOW_HEIGHT)
	{
		fprintf(stderr, "Square coords out of bounds!\n");
		return;
	}
    // Draw lines between all four corners
    	draw_line(game, square->tl.x, square->tl.y, square->tr.x,
    		square->tr.y, color);
    	draw_line(game, square->tr.x, square->tr.y, square->br.x,
    		square->br.y, color);
    	draw_line(game, square->br.x, square->br.y, square->bl.x,
    		square->bl.y, color);
    	draw_line(game, square->bl.x, square->bl.y, square->tl.x,
    		square->tl.y, color);
}

void move_square(t_square *square, int keycode, t_game *game) 
{
    int step = 10;
    int dx = 0;
    int dy = 0;

    if (keycode == KEY_LEFT || keycode == KEY_A)
        dx = -step;
    else if (keycode == KEY_RIGHT || keycode == KEY_D)
        dx = step;
    else if (keycode == KEY_UP || keycode == KEY_W)
        dy = -step;
    else if (keycode == KEY_DOWN || keycode == KEY_S)
        dy = step;

    // Apply movement to all corners of the square
    square->tl.x += dx;
    square->tl.y += dy;
    square->tr.x += dx;
    square->tr.y += dy;
    square->br.x += dx;
    square->br.y += dy;
    square->bl.x += dx;
    square->bl.y += dy;

    render_frame(game);
}

