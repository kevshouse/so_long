#include "../includes/so_long.h"
#include <string.h>


/*void clear_buffer(t_game *game)
{
	printf("Clearing buffer...\n");
	// Assuming game->buffers[0] is the buffer you want to clear
	void *buffer = game->buffers[0];
	printf("Getting buffer data address...\n");
	char *buffer_data = mlx_get_data_addr(buffer, &game->bpp,
		&game->size_line, &game->endian);
	if (!buffer)
	{
		fprintf(stderr, "Buffer is NULL, cannot clear!\n");
		return;
	}
    
	// Clear the buffer with a specified color (e.g., black)
	int color = 0x000000; // Change this to the desired clear color
	for (int y = 0; y < WINDOW_HEIGHT; y++)
	{
		for (int x = 0; x < WINDOW_WIDTH; x++)
		{
			int pixel = y * game->size_line + x * (game->bpp / 8);
			*(unsigned int *)(buffer_data + pixel) = color;
		}
	}
}*/

void clear_buffer(t_game *game)
{
    int buffer_size = WINDOW_WIDTH * WINDOW_HEIGHT * (game->bpp / 8);
    memset(game->buffer_data, 0, buffer_size); // Clear back buffer
}

/*void swap_buffers(t_game *game)
{
    // Example: Swap front and back buffers if using double buffering
	void *temp = game->buffers[0];
	game->buffers[0] = game->buffers[1];
	game->buffers[1] = temp;
    // Update buffer_data pointer if necessary
	game->buffer_data = mlx_get_data_addr(game->buffers[0],
		&game->bpp, &game->size_line, &game->endian);
}*/

void swap_buffers(t_game *game)
{
    // Swap buffer indices
    game->current_buffer ^= 1;
    
    // Set active buffer data
    game->buffer_data = mlx_get_data_addr(
        game->buffers[game->current_buffer],
        &game->bpp,
        &game->size_line,
        &game->endian
    );
}



    // Load dolphin image
/*    data.dolphin_img = mlx_xpm_file_to_image(data.mlx, "dolphin.xpm",
        &data.dolphin_width, &data.dolphin_height);
    if (data.dolphin_img)
    {
        data.dolphin_data = mlx_get_data_addr(data.dolphin_img, &data.bpp,
            &data.dolphin_size_line, &data.endian);
    }
    else
    {
        fprintf(stderr, "Warning: Failed to load dolphin.xpm\n");
    }*/

void draw_dolphin(t_game *game)
{
    int scaled_width = game->dolphin.width * SCALE_FACTOR;
    int scaled_height = game->dolphin.height * SCALE_FACTOR;

    int x = (WINDOW_WIDTH - scaled_width) / 2;
    int y = (WINDOW_HEIGHT - scaled_height) / 2;

    for (int i = 0; i < game->dolphin.height; i++) {
        for (int j = 0; j < game->dolphin.width; j++) {
            int src_pixel = i * game->dolphin.size_line + j * (game->dolphin.bpp / 8);
            unsigned int color = *(unsigned int *)(game->dolphin.data + src_pixel);

            // Draw SCALE_FACTOR x SCALE_FACTOR block for each pixel
            for (int sy = 0; sy < SCALE_FACTOR; sy++) {
                for (int sx = 0; sx < SCALE_FACTOR; sx++) {
                    int dst_x = x + j * SCALE_FACTOR + sx;
                    int dst_y = y + i * SCALE_FACTOR + sy;

                    if (dst_x >= 0 && dst_x < WINDOW_WIDTH && 
                        dst_y >= 0 && dst_y < WINDOW_HEIGHT) 
                    {
                        int dst_pixel = dst_y * game->size_line + dst_x * (game->bpp / 8);
                        *(unsigned int *)(game->buffer_data + dst_pixel) = color;
                    }
                }
            }
        }
    }
}

int render_frame(void *param)
{
    t_game *game = (t_game *)param;
    
    // Safety checks
    if (!game->win || !game->mlx || !game->buffers[0])
    {
        fprintf(stderr, "Critical components missing in render_frame!\n");
        return (1);
    }

    clear_buffer(game);
    //*(unsigned int *)(game->buffer_data + 0) = 0xFF0000; // Red pixel at top-left
    // 1. Draw dolphin first (background element)
    draw_dolphin(game);
    
    // 2. Draw squares on top of dolphin
    draw_square(game, &game->squares[0], 0xFFFFFF);
    draw_square(game, &game->squares[1], 0xFF0000);

    // 3. Swap and display
    swap_buffers(game);
    
    // 4. Explicitly push to window
    mlx_put_image_to_window(
        game->mlx, 
        game->win, 
        game->buffers[0],  // Or whichever is your front buffer
        0, 0
    );
    
    return (0);
}


