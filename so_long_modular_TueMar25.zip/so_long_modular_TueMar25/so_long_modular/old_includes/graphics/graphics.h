#ifndef GRAPHICS_H
# define GRAPHICS_H

# include "shapes/shapes.h" // Ensure this is included first
# include "so_long.h"

typedef struct s_game t_game; // Forward declaration
typedef struct s_square t_square; // Forward declaration

typedef struct s_image
{
	void		*img_ptr;
	char		*data;
	int			bpp;
	int			size_line;
	int			endian;
	int			width;
	int			height;
}				t_image;

typedef struct s_data
{
	void		*mlx;
	void		*win;
	void		*front_buffer;
	void		*back_buffer;
	char		*front_data;
	char		*back_data;
	int			bpp;
	int			size_line;
	t_square	dynamic_square; // Declare dynamic square
	t_square	second_dynamic_square; // Declare second dynamic square

	void		*dolphin_img;
	char		*dolphin_data;
	int			dolphin_width;
	int			dolphin_height;
	int			dolphin_size_line;
	int			endian;
}				t_data;

void			load_image(t_game *game, t_image *img, char *path);
void			clear_buffer(t_game *game);
void			draw_dolphin(t_game *game);
void			draw_square(t_game *game, t_square *square, int color); // Function prototype for drawing a square
void			swap_buffers(t_game *game);
int				render_frame(void *param);

#endif // GRAPHICS_H
