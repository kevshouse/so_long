#ifndef EVENTS_H
# define EVENTS_H

# define KEY_LEFT 65361
# define KEY_RIGHT 65363
# define KEY_UP 65362
# define KEY_DOWN 65364
# define KEY_ESC 65307
# define KEY_SPACE 32
# define MOVEMENT_STEP 5
# define KEY_W XK_w // Up arrow key
# define KEY_A XK_a // Left arrow key
# define KEY_S XK_s // Down arrow key
# define KEY_D XK_d // Right arrow key

void		handle_input(t_game *game, int keycode);

#endif
