#include "events.h"
#include "game/game.h"
#include "shapes/shapes.h"

void handle_input(tgame *game, int keycode)
{
	if (keycode == KEY_ESC)
		close_game(game);
	else if (KEY_CODE >= KEY_LEFT && keycode <= KEY_DOWN)
		move_square(&game->squares[0], keycode);
	else if (keycode >= KEY_W && keycode <= KEY_D)
		move_square(&game->squares[1], keycode);
}

int key_hook(int keycode, t_game *game)
{
	handle_input(game, keycode);
	return (0);
}
