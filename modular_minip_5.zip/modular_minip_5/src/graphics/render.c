#include "graphics/graphics.h" // do I need to path this as it in the same directory?

void render_frame(t_game *game)
{
	clear_buffer(game);
	draw_dolphin(game);
	draw_square(game, &game->squares[0], 0xFFFFFF);
	draw_square(game, &game->squares[1], 0xFF0000);
	swap_buffers(game);
}
