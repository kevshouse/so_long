#ifndef GRAPHICS_H
# define GRAPHICS_H

# include "../shapes/shapes.h" // t_square should be defined there.

void	draw_square(t_game *game, t_square *square, int color);

#endif
