#include "game/game.h"
#include "graphics/graphics.h"

void init_game(t_game *game)
{
	game->mlx = mlx_init();
	game->win = mlx_new_window(game->mlx, WINDOW_WIDTH,
		WINDOW_HEIGHT, "minip");
	game->buffers[0] = mlx_new_image(game->mlx, WINDOW_WIDTH,
		WINDOW_HEIGHT);
	game->buffers[1] = mlx_new_image(game->mlx, WINDOW_WIDTH,
		WINDOW_HEIGHT);
	game->buffer_data = mlx_get_data_addr(game->buffers[1],
		&game->bpp, &game->size_line, &game->endian);
	// Initialise squares
	game->squares[0] = create_square((t_point){10, 10},
		(t_point){15, 15}, (t_point){10, 15});
	game->squares[1] = create_square((t_point){100, 100},
		(t_point){105, 105}, (t_point){100, 105});
	// Load dolphin image
	load_image(game, &game->dolphin, "assets/dolphin_trans.xpm");
	
}
