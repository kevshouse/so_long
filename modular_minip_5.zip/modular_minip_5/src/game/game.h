#ifndef GAME_H
# define GAME_H

# include "../mlx_linux/mls.h"
# include "shapes/shapes.h"

# define WINDOW_WIDTH 600
# define WINDOW_HEIGHT 300
# define SCALE_FACTOR 0.05

typedef struct s_game
{
	void		*mlx;
	void		*win;
	void		*buffers[2];
	char		*buffer_data;
	int		bpp;
	int		size_line;
	t_square	squares[2];
	t_image		dolphin;
}		t_game;

// Initialisation
void		int_game(t_game *game);
void		setup_hooks(t_game *game);

// Cleanup
int		close_game(t_game *game);

#endif
