#include "game/game.h"
#include "events/events.h"
#include "graphics/graphics.h"

int	main(void)
{
	t_game	game;
	
	init_game(&game);
	setup_hooks(&game);
	mlx_loop(game.mlx);
	return (0);
}
