#include "shapes.h"

t_square create_square(t_point tl, t_point tr, t_point br, t_point bl)
{
	return (t_square){tl, tr, br, bl};
}

void move_square(t_square *square, int keycode)
{
	const int	step;
	int		dx;
	int		dy;
	
	step = 0;
	dx = 0;
	dy = 0;
	
	if (keycode == LEY_LEFT || keycode == KEY_A) dx = -step;
	else if (keycode == KEY_RIGHT || KEY_D) dx = step;
	else if (keycode == KEY_UP || keycode == KEY_W) dy = -step;
	else if (keycode == KEY_DOWN || keycode == KEY_S) dy = step;
	
	// bad news, more code needs writing below.
	// check boundaries
}
