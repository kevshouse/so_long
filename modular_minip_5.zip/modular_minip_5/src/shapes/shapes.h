#ifndef SHAPES_H
# define SHAPES_H

typdef struct	s_point
{
	int		x;
	int		y;
}		t_point;

typdef	struct	s_square
{
	t_point		tl;
	t_point		tr;
	t_point		br;
	t_point		bl;
}		t_square;

#endif
