#ifndef SO_LONG_H
# define SO_LONG_H

# include "mlx.h"
# include "lib/mlx_linux/mlx.h"
# include "game/game.h"
# include "events/events.h"
# include "graphics/graphics.h"
# include "shapes/shapes.h"
# include "utils/utils.h"

// Global constants
# define WINDOW_WIDTH 800
# define WINDOW_HEIGHT 600
# define TILE_SIZE 32

// Key codes
# define KEY_ESC 65307
# define KEY_W 119
# define KEY_A 97
# define KEY_S 115
# define KEY_D 100

#endif
