#ifndef GAME_H
# define GAME_H

# include <stdlib.h>
# include "mlx.h"
# include "shapes/shapes.h"
# include "graphics/graphics.h"
# include "events/events.h"

# define WINDOW_WIDTH 800
# define WINDOW_HEIGHT 600
# define SCALE_FACTOR 0.05

void setup_hooks(t_game *game);

typedef struct s_game
{
	void		*mlx;
	void		*win;
	void		*buffers[2];
	char		*buffer_data;
	int		bpp;
	int		size_line;
	int		endian;
	t_square	squares[2];
	t_image		dolphin;
}		t_game;

// Initialisation
void		init_game(t_game *game);
void		setup_hooks(t_game *game);
// Cleanup
int		close_game(t_game *game);

#endif
