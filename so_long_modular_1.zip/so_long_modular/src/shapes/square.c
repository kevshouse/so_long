#include "mlx.h"
#include "shapes/shapes.h"
#include "game/game.h"
#include "graphics/graphics.h"

t_square create_square(t_point tl, t_point tr, t_point br, t_point bl, int color)
{
	t_square square;

	square.tl = tl;
	square.tr = tr;
	square.br = br;
	square.bl = bl;
	square.color = color; // Set the color

	return square;
}

void draw_square(t_game *game, t_square *square, int color)
{
    // Draw lines between each corner of the square
	 mlx_pixel_put(game->mlx, game->win, square->tl.x, 
	 	square->tl.y, color);
    	mlx_pixel_put(game->mlx, game->win, square->tr.x,
    		square->tr.y, color);
    	mlx_pixel_put(game->mlx, game->win, square->br.x,
    		square->br.y, color);
    	mlx_pixel_put(game->mlx, game->win, square->bl.x,
    		square->bl.y, color);
    // Add line drawing logic between points for full square rendering
}
void move_square(t_square *square, int keycode, t_game *game)
{
	int		step;
	int		dx;
	int		dy;
	
	step = 10;
	dx = 0;
	dy = 0;
	
	if (keycode == KEY_LEFT || keycode == KEY_A)
		dx = -step;
	else if (keycode == KEY_RIGHT || keycode == KEY_D)
		dx = step;
	else if (keycode == KEY_UP || keycode == KEY_W)
		dy = -step;
	else if (keycode == KEY_DOWN || keycode == KEY_S)
		dy = step;
	// Calculate current min and max coordinates
	int min_x = square->tl.x;
	if (square->tr.x < min_x) min_x = square->tr.x;
	if (square->br.x < min_x) min_x = square->br.x;
	if (square->bl.x < min_x) min_x = square->bl.x;

	int max_x = square->tl.x;
	if (square->tr.x > max_x) max_x = square->tr.x;
	if (square->br.x > max_x) max_x = square->br.x;
	if (square->bl.x > max_x) max_x = square->bl.x;

	int min_y = square->tl.y;
	if (square->tr.y < min_y) min_y = square->tr.y;
	if (square->br.y < min_y) min_y = square->br.y;
	if (square->bl.y < min_y) min_y = square->bl.y;

	int max_y = square->tl.y;
	if (square->tr.y > max_y) max_y = square->tr.y;
	if (square->br.y > max_y) max_y = square->br.y;
	if (square->bl.y > max_y) max_y = square->bl.y;
	
	// check WINDOW_WIDTH boundaries
	if (min_x + dx < 0)
		dx = -min_x;
	if (max_x + dx > WINDOW_WIDTH)
		dx = WINDOW_WIDTH - max_x;
	// check WINDOW_HEIGHT boundaries
	if (min_y + dy < 0)
		dy = -min_y;
	if (max_y + dy > WINDOW_HEIGHT)
		dy = WINDOW_HEIGHT - max_y;
	
	// Apply movement to all corners of the square
	square->tl.x += dx;
	square->tl.y += dy;
	square->tr.x += dx;
	square->tr.y += dy;
	square->br.x += dx;
	square->br.y += dy;
	square->bl.x += dx;
	square->bl.y += dy;
	mlx_expose_hook(game->win, mlx_expose_hook, game);
	render_frame(game);
}
