#include "events/events.h"
#include "game/game.h"
#include "shapes/shapes.h"

int handle_input(int keycode, void *param) 
{
	t_game *game = (t_game *)param;

	if (keycode == KEY_ESC)
		close_game(game);
	else
		move_square(&game->squares[0], keycode, game);
	return (0); // Return an int
}

/*int key_hook(int keycode, t_game *game)
{
	handle_input(game, keycode);
	return (0);
}*/

int key_hook(int keycode, void *param)
{
	handle_input(keycode, (t_game *)param);
	return (0);
}


