// src/main.c
#include "game/game.h"

int main(void)
{
    t_game game;
    init_game(&game);
    setup_hooks(&game); // Ensure this initializes MLX loops
    mlx_loop(game.mlx);
    return 0;
}
