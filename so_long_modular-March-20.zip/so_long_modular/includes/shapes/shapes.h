#ifndef SHAPES_H
# define SHAPES_H
# include "mlx.h"
# include "events/events.h"

typedef struct	s_point
{
	int		x;
	int		y;
}		t_point;

typedef	struct	s_square
{
	t_point		tl;
	t_point		tr;
	t_point		br;
	t_point		bl;
	int		color;
}		t_square;

t_square create_square(t_point tl, t_point tr, t_point br, t_point bl, int color);
//void	move_square(t_square *square, int direction);

void move_square(t_square *square, int keycode, t_game *game);

#endif
