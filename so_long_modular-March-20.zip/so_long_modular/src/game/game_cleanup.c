// src/game/game_cleanup.c
#include "game/game.h"

int close_game(t_game *game)
{
    mlx_destroy_window(game->mlx, game->win);
    mlx_destroy_image(game->mlx, game->dolphin.img_ptr);
    mlx_destroy_display(game->mlx);
    //exit(0);
    return (0);
}
