#ifndef SO_LONG_H
# define SO_LONG_H

# include <X11/X.h>
# include <X11/keysym.h>
# include "events/events.h"
# include "mlx.h"
//# include "inc/mlx_linux/mlx.h"
# include "game/game.h"

# include "graphics/graphics.h"
# include "shapes/shapes.h"
# include "utils/utils.h"

// Global constants
# define WINDOW_WIDTH 800
# define WINDOW_HEIGHT 600
# define TILE_SIZE 32

int render_frame(void *param);
#endif
