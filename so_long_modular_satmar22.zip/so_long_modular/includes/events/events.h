/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   events.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/22 14:29:49 by keanders          #+#    #+#             */
/*   Updated: 2025/03/22 14:32:03 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef EVENTS_H
# define EVENTS_H

# include "so_long.h"
# include <X11/keysym.h>

// Keycode definitions
# define KEY_ESC XK_Escape
# define KEY_W XK_w
# define KEY_A XK_a
# define KEY_S XK_s
# define KEY_D XK_d
# define KEY_UP XK_Up
# define KEY_DOWN XK_Down
# define KEY_LEFT XK_Left
# define KEY_RIGHT XK_Right

# include "mlx.h"

typedef struct s_game t_game; // Forward declaration
// void		handle_input(t_game *game, int keycode);
// includes/events/input.h
int	handle_input(int keycode, void *param);
#endif // EVENTS_H
