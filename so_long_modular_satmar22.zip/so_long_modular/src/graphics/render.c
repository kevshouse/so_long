#include "so_long.h"
#include "game/game.h"
#include "shapes/shapes.h"
#include "graphics/graphics.h"


void clear_buffer(t_game *game)
{
	printf("Clearing buffer...\n");
	// Assuming game->buffers[0] is the buffer you want to clear
	void *buffer = game->buffers[0];
	printf("Getting buffer data address...\n");
	char *buffer_data = mlx_get_data_addr(buffer, &game->bpp,
		&game->size_line, &game->endian);
	if (!buffer)
	{
		fprintf(stderr, "Buffer is NULL, cannot clear!\n");
		return;
	}
    
	// Clear the buffer with a specified color (e.g., black)
	int color = 0x000000; // Change this to the desired clear color
	for (int y = 0; y < WINDOW_HEIGHT; y++)
	{
		for (int x = 0; x < WINDOW_WIDTH; x++)
		{
			int pixel = y * game->size_line + x * (game->bpp / 8);
			*(unsigned int *)(buffer_data + pixel) = color;
		}
	}
}


void swap_buffers(t_game *game)
{
    // Example: Swap front and back buffers if using double buffering
	void *temp = game->buffers[0];
	game->buffers[0] = game->buffers[1];
	game->buffers[1] = temp;
    // Update buffer_data pointer if necessary
	game->buffer_data = mlx_get_data_addr(game->buffers[0],
		&game->bpp, &game->size_line, &game->endian);
}

void draw_dolphin(t_game *game)
{
    if (!game->dolphin.img_ptr) // Assuming dolphin image is stored in game
        return;

    int scaled_width = game->dolphin.width * SCALE_FACTOR; // Adjust as necessary
    int scaled_height = game->dolphin.height * SCALE_FACTOR; // Adjust as necessary

    int x = (WINDOW_WIDTH - scaled_width) / 2;
    int y = (WINDOW_HEIGHT - scaled_height) / 2;

    for (int i = 0; i < game->dolphin.height; i++)
    {
        for (int j = 0; j < game->dolphin.width; j++)
        {
            int src_pixel = i * game->dolphin.size_line + j * (game->bpp / 8);
            unsigned int color = *(unsigned int *)(game->dolphin.data + src_pixel);
            if (color != 0x0E1A39)
            {
                int dst_x = x + (int)(j * SCALE_FACTOR);
                int dst_y = y + (int)(i * SCALE_FACTOR);
                if (dst_x >= 0 && dst_x < WINDOW_WIDTH && 
                    dst_y >= 0 && dst_y < WINDOW_HEIGHT)
                {
                    int dst_pixel = dst_y * game->size_line + dst_x * (game->bpp / 8);
                    *(unsigned int *)(game->buffer_data + dst_pixel) = color;
                }
            }
        }
    }
}

int render_frame(void *param)
{
	t_game *game = (t_game *)param;
	if (!game->win || !game->mlx){
	//rintf("render_frame_abbend!");
		return (1);}
	clear_buffer(game);
	draw_dolphin(game);
	//draw_dolphin_to_buffer(game); // Ensure this function also  exists if needed
	draw_square(game, &game->squares[0], 0xFFFFFF);
	draw_square(game, &game->squares[1], 0xFF0000);
	swap_buffers(game);
	return (0);
}
