// src/main.c
#include "game/game.h"
#include <stdlib.h>
#include "../includes/utils/utils.h"
// Define DEBUG macro
#define DEBUG 1

#if DEBUG
#define DEBUG_PRINT(fmt, ...) printf(fmt, ##__VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...) // No operation
#endif


int main(void)
{
	DEBUG_PRINT("Starting the application...\n");
	log_message("Application started.");
	t_game game; // Declare the game variable
	init_game(&game);
	printf("Game init complete.\n");
	setup_hooks(&game);

	//render_frame(&game);
	printf("Entering main mlx loop..\n");
	mlx_loop(game.mlx);
	return (0);
}
