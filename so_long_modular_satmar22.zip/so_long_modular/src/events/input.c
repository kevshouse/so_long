#include "so_long.h"
#include "events/events.h"
#include "game/game.h"
#include "shapes/shapes.h"

int handle_input(int keycode, void *param) 
{
	t_game *game = (t_game *)param;
	printf("Key pressed: %d\n", keycode);
	if (keycode == KEY_ESC)
		close_game(game);
	else if (keycode == KEY_LEFT || keycode == KEY_A)
		move_square(&game->squares[0], keycode, game);
	return (0); // Return an int
}

int key_hook(int keycode, void *param)
{
	handle_input(keycode, (t_game *)param);
	return (0);
}

// Defined in game_init.c
/*void setup_hooks(t_game *game)
{
	mlx_hook(game->win, KeyPress, KeyPressMask, handle_input, game);
	mlx_hook(game->win, DestroyNotify, 
		StructureNotifyMask, close_game, game);
	mlx_expose_hook(game->win, (void *)render_frame, game);
}*/


