#include "so_long.h"
#include "game/game.h"
#include "graphics/graphics.h"
#include <X11/X.h>
#include "shapes/shapes.h" // Include the header for draw_square

void init_game(t_game *game)
{
	printf("init mlx ...\n");
	    // src/game/game_init.
	game->mlx = mlx_init();
	if (!game->mlx)
	{
		fprintf(stderr, "Error initialising MLX\n");
		exit(EXIT_FAILURE);
	}
	printf("Creating new window...\n");	
	game->win = mlx_new_window(game->mlx, WINDOW_WIDTH,
		WINDOW_HEIGHT, "Game");
	if(!game->win)
	{
		fprintf(stderr, "Failed to create window.\n");
		return;
	}
    // Define points for the first square
    t_point top_left_1 = {10, 10};
    t_point top_right_1 = {20, 10};
    t_point bottom_right_1 = {20, 20};
    t_point bottom_left_1 = {10, 20};

    // Create the first square
    game->squares[0] = create_square(top_left_1, top_right_1,
    	bottom_right_1, bottom_left_1, 0xFF0000);

    // Define points for the second square
    t_point top_left_2 = {30, 30};
    t_point top_right_2 = {40, 30};
    t_point bottom_right_2 = {40, 40};
    t_point bottom_left_2 = {30, 40};

    // Create the second square
    game->squares[1] = create_square(top_left_2, top_right_2,
    	bottom_right_2, bottom_left_2, 0x00FF00);
}
void setup_hooks(t_game *game)
{
	mlx_hook(game->win, Expose, ExposureMask, render_frame, game);
	mlx_hook(game->win, KeyPress, KeyPressMask, handle_input, game);
	mlx_hook(game->win, DestroyNotify, StructureNotifyMask,
		close_game, game);
}


