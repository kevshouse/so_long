// so_long.h
#ifndef SO_LONG_H
#define SO_LONG_H

#include <stdio.h>
#include <stdlib.h>
#include <X11/X.h>
#include <X11/keysym.h>
#include "mlx.h"

// Define keycode constants
#define KEY_LEFT XK_Left
#define KEY_RIGHT XK_Right
#define KEY_UP XK_Up
#define KEY_DOWN XK_Down
#define KEY_A XK_a
#define KEY_D XK_d
#define KEY_W XK_w
#define KEY_S XK_s
#define KEY_ESC XK_Escape

// Define constants
#define MOVEMENT_STEP 5
#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600
#define TILE_SIZE 32
#define SCALE_FACTOR 0.05

// Forward declarations
typedef struct s_game t_game;
typedef struct s_image t_image;
typedef struct s_square t_square;

// Point structure
typedef struct s_point {
	int x;
	int y;
} t_point;

// Square structure
struct s_square {
	t_point tl;
	t_point tr;
	t_point br;
	t_point bl;
	int color;
};

// Image structure
struct s_image {
	void *img_ptr;
	char *data;
	int bpp;
	int size_line;
	int endian;
	int width;
	int height;
};

// Data structure
typedef struct s_data {
	void *mlx;
	void *win;
	void *front_buffer;
	void *back_buffer;
	char *front_data;
	char *back_data;
	int bpp;
	int size_line;
	t_square dynamic_square;
	t_square second_dynamic_square;
	void *dolphin_img;
	char *dolphin_data;
	int dolphin_width;
	int dolphin_height;
	int dolphin_size_line;
	int endian;
}t_data;

// Game structure
struct s_game {
	void *mlx;
	void *win;
	void *buffers[2];
	char *buffer_data;
	int  current_buffer;
	int bpp;
	int size_line;
	int endian;
	t_square squares[2];
	t_image dolphin;
} ;

// Function declarations
int render_frame(void *param);
void init_game(t_game *game);
void setup_hooks(t_game *game);
int close_game(t_game *game);
int handle_input(int keycode, void *param);
void clear_buffer(t_game *game);
void swap_buffers(t_game *game);
void draw_dolphin(t_game *game);
void draw_square(t_game *game, t_square *square, int color);
void move_square(t_square *square, int keycode, t_game *game);
void draw_line(t_game *game, int x0, int y0, int x1, int y1, int color);
t_square create_square(t_point tl, t_point tr, t_point br, t_point bl, int color);
extern void log_message(const char *message);

#endif // SO_LONG_H
