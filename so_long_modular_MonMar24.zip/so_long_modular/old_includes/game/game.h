/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   game.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/22 14:30:17 by keanders          #+#    #+#             */
/*   Updated: 2025/03/22 15:46:24 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GAME_H
# define GAME_H

# include "shapes/shapes.h" // Ensure this is included first
# include "events/events.h"
# include "graphics/graphics.h"
# include "mlx.h"
# include "so_long.h"
# include <stdlib.h>

# define WINDOW_WIDTH 800
# define WINDOW_HEIGHT 600
# define SCALE_FACTOR 0.05

void			setup_hooks(t_game *game);

typedef struct s_game
{
	void		*mlx;
	void		*win;
	void		*buffers[2];
	char		*buffer_data;
	int			bpp;
	int			size_line;
	int			endian;
	t_square	squares[2]; // Declare array of squares
	t_image		dolphin;
}				t_game;

// Initialisation
void			init_game(t_game *game);
void			setup_hooks(t_game *game);
// Cleanup
int				close_game(t_game *game);

#endif // GAME_H
