#include "./mlx_linux/mlx.h"
#include <stdlib.h>

#define ESC_KEY 53
#define WIDTH 800
#define HEIGHT 600

typedef struct s_data {
    void    *mlx;
    void    *win;
    void    *img;
}   t_data;

int handle_key(int keycode, t_data *data)
{
    if (keycode == ESC_KEY)
    {
        mlx_destroy_image(data->mlx, data->img);
        mlx_destroy_window(data->mlx, data->win);
        exit(0);
    }
    return (0);
}

int main(void)
{
    t_data  data;
    int     img_width;
    int     img_height;

    data.mlx = mlx_init();
    data.win = mlx_new_window(data.mlx, WIDTH, HEIGHT, "XPM Viewer");
    data.img = mlx_xpm_file_to_image(data.mlx, "texture.xpm", &img_width, &img_height);
    
    if (!data.img)
    {
        mlx_destroy_window(data.mlx, data.win);
        exit(1);
    }
    
    mlx_put_image_to_window(data.mlx, data.win, data.img, 0, 0);
    mlx_hook(data.win, 2, 1L<<0, (int (*)())handle_key, &data);
    mlx_loop(data.mlx);
    
    return (0);
}
