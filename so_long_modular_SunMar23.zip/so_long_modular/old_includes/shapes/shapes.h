/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   shapes.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/22 14:31:35 by keanders          #+#    #+#             */
/*   Updated: 2025/03/22 15:13:49 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SHAPES_H
# define SHAPES_H
# include "events/events.h"
# include "graphics/graphics.h"
# include "mlx.h"
# include "so_long.h"

typedef struct s_point
{
	int		x;
	int		y;
}			t_point;

typedef struct s_game t_game; // Forward declaration
typedef struct s_square
{
	t_point	tl;
	t_point	tr;
	t_point	br;
	t_point	bl;
	int		color;
}			t_square;

void		draw_line(t_game *game, int x0, int y0, int x1, int y1, int color);
t_square	create_square(t_point tl, t_point tr, t_point br, t_point bl,
				int color);
void		move_square(t_square *square, int keycode, t_game *game);
#endif // SHAPES_H
