/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/22 14:31:06 by keanders          #+#    #+#             */
/*   Updated: 2025/03/22 14:42:15 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H

# include "mlx.h"
# include <X11/X.h>
# include <X11/keysym.h>
# include <stdio.h>
//# include "inc/mlx_linux/mlx.h"
# include "events/events.h"
# include "game/game.h"
# include "graphics/graphics.h"
# include "shapes/shapes.h"
#include "utils/utils.h"

// Global constants
# define WINDOW_WIDTH 800
# define WINDOW_HEIGHT 600
# define TILE_SIZE 32

int	render_frame(void *param);
#endif
