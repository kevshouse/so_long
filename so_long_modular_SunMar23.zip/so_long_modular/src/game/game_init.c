#include "../includes/so_long.h"
#include <X11/X.h>

void init_game(t_game *game)
{
    printf("init mlx ...\n");
    game->mlx = mlx_init();
    if (!game->mlx)
    {
        fprintf(stderr, "Error initialising MLX\n");
        exit(EXIT_FAILURE);
    }
    printf("MLX initialised Okay.\n");

    printf("Creating new window...\n");	
    game->win = mlx_new_window(game->mlx, WINDOW_WIDTH, WINDOW_HEIGHT, "Game");
    if(!game->win)
    {
        fprintf(stderr, "Failed to create window.\n");
        exit(EXIT_FAILURE);
    }
    printf("Window created successfully.\n");

    // Initialize buffers
    printf("Initializing buffers...\n");
    game->buffers[0] = mlx_new_image(game->mlx, WINDOW_WIDTH, WINDOW_HEIGHT);
    game->buffers[1] = mlx_new_image(game->mlx, WINDOW_WIDTH, WINDOW_HEIGHT);
    if (!game->buffers[0] || !game->buffers[1])
    {
        fprintf(stderr, "Failed to create buffers!\n");
        exit(EXIT_FAILURE);
    }
    printf("Buffers created successfully.\n");

    game->buffer_data = mlx_get_data_addr(game->buffers[0], &game->bpp, &game->size_line, &game->endian);
    if (!game->buffer_data)
    {
        fprintf(stderr, "Failed to get buffer data address!\n");
        exit(EXIT_FAILURE);
    }
    printf("Buffer data address obtained successfully.\n");

    // Initialize squares
    t_point top_left_1 = {10, 10};
    t_point top_right_1 = {20, 10};
    t_point bottom_right_1 = {20, 20};
    t_point bottom_left_1 = {10, 20};
    game->squares[0] = create_square(top_left_1, top_right_1, bottom_right_1, bottom_left_1, 0xFF0000);

    t_point top_left_2 = {30, 30};
    t_point top_right_2 = {40, 30};
    t_point bottom_right_2 = {40, 40};
    t_point bottom_left_2 = {30, 40};
    game->squares[1] = create_square(top_left_2, top_right_2, bottom_right_2, bottom_left_2, 0x00FF00);

    // Initialize dolphin image (if needed)
    // game->dolphin.img_ptr = mlx_xpm_file_to_image(game->mlx, "path/to/dolphin.xpm", &game->dolphin.width, &game->dolphin.height);
    // game->dolphin.data = mlx_get_data_addr(game->dolphin.img_ptr, &game->dolphin.bpp, &game->dolphin.size_line, &game->dolphin.endian);

    printf("Game init complete.\n");
}
void setup_hooks(t_game *game)
{
	mlx_hook(game->win, Expose, ExposureMask, render_frame, game);
	mlx_hook(game->win, KeyPress, KeyPressMask, handle_input, game);
	mlx_hook(game->win, DestroyNotify, StructureNotifyMask,
		close_game, game);
}

int handle_input(int keycode, void *param)
{
    t_game *game = (t_game *)param;
    printf("Key pressed: %d\n", keycode);
    if (keycode == KEY_ESC)
        close_game(game);
    else if (keycode == KEY_LEFT || keycode == KEY_A)
        move_square(&game->squares[0], keycode, game);
    return (0);
}
