# For 100 numbers
for i in {1..50}; do
    ARG=$(shuf -i 1-100 -n 100 | tr '\n' ' ')
    ./push_swap $ARG | wc -l
done | sort -n

# For 500 numbers
for i in {1..20}; do
    ARG=$(shuf -i 1-500 -n 500 | tr '\n' ' ')
    ./push_swap $ARG | wc -l
done | sort -n
