/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorting_machine.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/02 21:06:52 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/02 21:09:08 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SORTING_MACHINE_H
# define SORTING_MACHINE_H

# include "../libft/includes/libft.h"
# include "machine.h"

void	sorting_control(t_machine *m);

#endif
