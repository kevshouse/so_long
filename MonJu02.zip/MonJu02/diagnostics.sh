#!/bin/bash

# Fixed Push_Swap Diagnostic Script
# - Fixed AWK command
# - Enhanced operation simulation

# Configuration
TEST_COUNT=5
NUMBER_COUNT=5
MIN_VALUE=1
MAX_VALUE=10
CHECKER="./checker_linux"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Verify executables
if [ ! -f "./push_swap" ]; then
    echo -e "${RED}Error: push_swap executable not found!${NC}"
    echo "Run 'make' first to build the project"
    exit 1
fi

if [ ! -f "$CHECKER" ]; then
    echo -e "${RED}Error: Checker '$CHECKER' not found!${NC}"
    exit 1
fi

# Run tests
echo -e "${YELLOW}Starting diagnostic tests...${NC}"
echo "========================================================"

for ((i=1; i<=$TEST_COUNT; i++)); do
    # Generate random numbers
    ARG=$(shuf -i $MIN_VALUE-$MAX_VALUE -n $NUMBER_COUNT | tr '\n' ' ')
    echo -e "${BLUE}Test $i: Input = $ARG${NC}"

    # Run push_swap
    echo -e "${YELLOW}Running push_swap...${NC}"
    OPERATIONS=$(./push_swap $ARG 2>&1)
    EXIT_STATUS=$?
    OP_COUNT=$(echo "$OPERATIONS" | wc -l | awk '{print $1}')

    # Check for errors
    if [[ "$OPERATIONS" == *"Error"* ]]; then
        echo -e "${RED}push_swap reported an error!${NC}"
        echo "Output: $OPERATIONS"
        echo "Exit status: $EXIT_STATUS"
    else
        echo "Operations ($OP_COUNT):"
        echo "$OPERATIONS"
    fi

    # Run checker
    echo -e "${YELLOW}Running checker...${NC}"
    CHECKER_RESULT=$(echo "$OPERATIONS" | $CHECKER $ARG 2>&1)
    CHECKER_EXIT=$?

    if [ "$CHECKER_RESULT" == "OK" ]; then
        echo -e "${GREEN}Checker result: OK${NC}"
    else
        echo -e "${RED}Checker result: $CHECKER_RESULT${NC}"
        echo "Checker exit status: $CHECKER_EXIT"
    fi

    # Run visual validation - FIXED
    echo -e "${YELLOW}Visual validation:${NC}"
    echo "Initial stack: $ARG"
    echo "$OPERATIONS" | awk '{
        print "Operation: " $0;
        if ($0 == "sa") print "  Swap top two elements of A";
        else if ($0 == "sb") print "  Swap top two elements of B";
        else if ($0 == "ss") print "  Swap both A and B";
        else if ($0 == "pa") print "  Push from B to A";
        else if ($0 == "pb") print "  Push from A to B";
        else if ($0 == "ra") print "  Rotate A (shift up)";
        else if ($0 == "rb") print "  Rotate B (shift up)";
        else if ($0 == "rr") print "  Rotate both A and B";
        else if ($0 == "rra") print "  Reverse rotate A (shift down)";
        else if ($0 == "rrb") print "  Reverse rotate B (shift down)";
        else if ($0 == "rrr") print "  Reverse rotate both A and B";
    }'

    echo "========================================================"
done

# Stack trace diagnostics
echo -e "${YELLOW}Running stack trace diagnostics...${NC}"
SMALL_INPUTS=(
    "1"
    "1 2"
    "2 1"
    "1 2 3"
    "1 3 2"
    "2 1 3"
    "3 1 2"
    "3 2 1"
    "1 2 3 4"
    "4 3 2 1"
)

for input in "${SMALL_INPUTS[@]}"; do
    echo -e "${BLUE}Testing input: $input${NC}"
    echo "Operations:"
    ./push_swap $input
    CHECKER_RESULT=$(./push_swap $input | $CHECKER $input)
    echo "Checker result: $CHECKER_RESULT"
    echo "----------------------------------------"
done

# Final check with known-good input
echo -e "${YELLOW}Final validation with known-good input...${NC}"
KNOWNGODD_INPUT="2 1 3"
echo "Input: $KNOWNGODD_INPUT"
OPERATIONS=$(./push_swap $KNOWNGODD_INPUT)
echo "Operations: $OPERATIONS"
echo "Checker result: $(echo "$OPERATIONS" | $CHECKER $KNOWNGODD_INPUT)"

echo -e "${YELLOW}Diagnostics complete.${NC}"
