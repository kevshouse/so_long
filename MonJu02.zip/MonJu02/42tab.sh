#!/bin/bash

# 42tab.sh - Simple script to add tabs between return types and function names
# for 42 School style formatting

# Check for arguments
if [ $# -eq 0 ]; then
    echo "Usage: $0 <file1> [file2] [file3] ..."
    echo "Adds tabs between return types and function/variable names"
    exit 1
fi

# Process each file
for file in "$@"; do
    if [ ! -f "$file" ]; then
        echo "Error: File '$file' not found"
        continue
    fi
    
    echo "Processing: $file"
    
    # Apply clang-format first if available
    if command -v clang-format >/dev/null 2>&1; then
        clang-format -i "$file"
    fi
    
    # Create a temporary file
    temp_file=$(mktemp)
    
    # Define common C types pattern
    types="void|int|char|float|double|size_t|long|short|unsigned|signed|t_[a-zA-Z0-9_]+"
    
    # Use sed to replace spaces between type and name with a tab
    sed -E "
        # For basic types followed by identifier (functions and variables)
        s/^([[:space:]]*)(static[[:space:]]+)?(${types})[[:space:]]+([a-zA-Z_][a-zA-Z0-9_]*)/\1\2\3\t\4/g
        
        # For types with pointer asterisks
        s/^([[:space:]]*)(static[[:space:]]+)?(${types})[[:space:]]*([*]+)[[:space:]]*([a-zA-Z_][a-zA-Z0-9_]*)/\1\2\3 \4\t\5/g
        
        # For typedefs, structs, etc.
        s/^([[:space:]]*)(typedef[[:space:]]+)?(struct|union|enum)[[:space:]]+([a-zA-Z_][a-zA-Z0-9_]*)[[:space:]]+([a-zA-Z_][a-zA-Z0-9_]*)/\1\2\3\t\4\t\5/g
    " "$file" > "$temp_file"
    
    # Replace the original file
    mv "$temp_file" "$file"
    
    echo "Formatted: $file"
done

echo "All files processed"
exit 0