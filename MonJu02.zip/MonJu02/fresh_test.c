#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct s_node
{
    int value;
    struct s_node *next;
} t_node;

void print_hello(void);
int sum(int a, int b);
char *get_string(void);
double compute_average(int *numbers, int size);
t_node *create_node(int value);
void free_list(t_node **head);

int main(void)
{
    int numbers[] = {1, 2, 3, 4, 5};
    char *message;
    t_node *list = NULL;
    t_node *new_node;
    int i;

    print_hello();
    printf("Sum of 5 and 3 is %d\n", sum(5, 3));
    
    message = get_string();
    if (message != NULL)
    {
        printf("%s\n", message);
        free(message);
    }

    printf("Average: %.2f\n", compute_average(numbers, 5));

    for (i = 0; i < 5; i++)
    {
        new_node = create_node(i * 10);
        if (new_node)
        {
            new_node->next = list;
            list = new_node;
        }
    }

    free_list(&list);

    return 0;
}

void print_hello(void)
{
    printf("Hello, world!\n");
}

int sum(int a, int b)
{
    return a + b;
}

char *get_string(void)
{
    char *str = malloc(20);

    if (str != NULL)
    {
        strcpy(str, "Hello from 42!");
    }
    return str;
}

double compute_average(int *numbers, int size)
{
    int sum = 0;
    int i;

    for (i = 0; i < size; i++)
    {
        sum += numbers[i];
    }

    if (size > 0)
    {
        return (double)sum / size;
    }
    else
    {
        return 0.0;
    }
}

t_node *create_node(int value)
{
    t_node *node = malloc(sizeof(t_node));
    
    if (node != NULL)
    {
        node->value = value;
        node->next = NULL;
    }
    return node;
}

void free_list(t_node **head)
{
    t_node *current;
    t_node *next;

    if (head == NULL || *head == NULL)
        return;

    current = *head;
    while (current != NULL)
    {
        next = current->next;
        free(current);
        current = next;
    }
    *head = NULL;
}