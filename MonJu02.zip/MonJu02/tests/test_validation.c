#include "../include/machine.h"
// #include <criterion/criterion.h>
#include </sgoinfre/students/keanders/homebrew/Cellar/criterion/2.4.2_2/include/criterion/criterion.h>
#include <stdio.h>

Test(validation, duplicates)
{
	printf("=== RUNNING validation::duplicates ===\n");
	char      *values[] = {"1", "2", "1"};
	t_machine *m        = machine_init(3, values);

	cr_assert_null(m, "Machine should be NULL for duplicate values");
	printf("=== FINISHED validation::duplicates ===\n");
}

Test(validation, sorted_check)
{
	printf("=== RUNNING validation::sorted_check ===\n");
	char      *values[] = {"1", "2", "3"};
	t_machine *m        = machine_init(3, values);

	cr_assert_not_null(m);
	cr_assert(machine_is_sorted(m, STACK_A), "Stack should be sorted");

	// Perform a swap and check it becomes unsorted
	machine_execute(m, OP_SA);
	cr_assert_not(machine_is_sorted(m, STACK_A),
	              "Stack should be unsorted after swap");

	machine_free(m);
	printf("=== FINISHED validation::sorted_check ===\n");
}
