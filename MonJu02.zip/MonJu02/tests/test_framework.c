// #include <criterion/criterion.h>
//  #include <criterion/criterion.h>
#include </sgoinfre/students/keanders/homebrew/Cellar/criterion/2.4.2_2/include/criterion/criterion.h>

// Basic test to verify Criterion is working
Test(framework, basic_pass)
{
	cr_assert(1, "This test should always pass");
}

// Uncomment to verify failure reporting
/*
Test(framework, basic_fail) {
    cr_assert(0, "This test should always fail");
}
*/
