#include <stdio.h>
#include <stdlib.h>

// Function declarations
void	print_hello(void);
int	sum(int a, int b);
char *	get_string(void);
double	compute_average(int *numbers, int size);

// Function pointer type
typedef int (*operation)(int, int);

// Function definitions
void	print_hello(void)
{
	printf("Hello, world!\n");
}

int	sum(int a, int b)
{
	return a + b;
}

char *	get_string(void)
{
	char *	str = malloc(12);

	if(str != NULL)
	{
		sprintf(str, "Hello there");
	}
	return str;
}

double	compute_average(int *numbers, int size)
{
	int	sum = 0;
	int	i;

	for(i = 0; i < size; i++)
	{
		sum += numbers[i];
	}

	if(size > 0)
	{
		return (double)sum / size;
	}
	else
	{
		return 0.0;
	}
}

int	main(void)
{
	int	nums[] = { 1, 2, 3, 4, 5 };
	char *	message;

	print_hello();
	printf("Sum of 5 and 3 is %d\n", sum(5, 3));

	message = get_string();
	if(message != NULL)
	{
		printf("%s\n", message);
		free(message);
	}

	printf("Average: %.2f\n", compute_average(nums, 5));

	return 0;
}