#!/bin/bash

# Configuration
TEST_COUNT=50
NUMBER_COUNT=500
MIN_VALUE=1
MAX_VALUE=1000
CHECKER="./checker_linux"  # Change to checker_OS if available

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Verify checker exists
if [ ! -f "$CHECKER" ]; then
    echo -e "${RED}Error: Checker '$CHECKER' not found!${NC}"
    exit 1
fi

# Verify push_swap exists
if [ ! -f "./push_swap" ]; then
    echo -e "${RED}Error: push_swap executable not found!${NC}"
    exit 1
fi

# Run tests
total_ops=0
min_ops=100000
max_ops=0
fail_count=0

echo -e "${BLUE}Starting $TEST_COUNT tests with $NUMBER_COUNT numbers...${NC}"
echo "========================================================"

for ((i=1; i<=$TEST_COUNT; i++)); do
    # Generate random numbers
    ARG=$(shuf -i $MIN_VALUE-$MAX_VALUE -n $NUMBER_COUNT | tr '\n' ' ')

    # Run push_swap and capture operations
    OPERATIONS=$(./push_swap $ARG 2>&1)
    OP_COUNT=$(echo "$OPERATIONS" | wc -l | tr -d ' ')

    # Run checker
    CHECKER_RESULT=$(echo "$OPERATIONS" | $CHECKER $ARG 2>&1)

    # Validate results
    if [ "$CHECKER_RESULT" != "OK" ]; then
        echo -e "${RED}Test $i: KO!${NC} (Operations: $OP_COUNT)"
        echo -e "${YELLOW}Input:${NC} $ARG"
        fail_count=$((fail_count + 1))
    else
        # Update stats
        total_ops=$((total_ops + OP_COUNT))

        if [ $OP_COUNT -lt $min_ops ]; then
            min_ops=$OP_COUNT
        fi

        if [ $OP_COUNT -gt $max_ops ]; then
            max_ops=$OP_COUNT
        fi

        # Show progress
        if [ $((i % 10)) -eq 0 ]; then
            echo -e "${GREEN}Test $i: OK${NC} (Operations: $OP_COUNT)"
        fi
    fi
done

# Calculate average if we had successful tests
success_count=$((TEST_COUNT - fail_count))

if [ $success_count -gt 0 ]; then
    average_ops=$(echo "scale=2; $total_ops / $success_count" | bc)
else
    average_ops=0
fi

# Print summary
echo "========================================================"
echo -e "${BLUE}TEST SUMMARY${NC}"
echo "========================================================"
echo -e "Tests completed: ${YELLOW}$TEST_COUNT${NC}"
echo -e "Successful sorts: ${GREEN}$success_count${NC}"
echo -e "Failed sorts: ${RED}$fail_count${NC}"
echo "--------------------------------------------------------"
echo -e "Average operations: ${BLUE}$average_ops${NC}"
echo -e "Minimum operations: ${GREEN}$min_ops${NC}"
echo -e "Maximum operations: ${RED}$max_ops${NC}"
echo "--------------------------------------------------------"
echo -e "Project benchmark: ${YELLOW}≤5500 operations${NC}"

# Check against benchmark
if [ $max_ops -le 5500 ] && [ $fail_count -eq 0 ]; then
    echo -e "${GREEN}SUCCESS: All tests passed within benchmark!${NC}"
    exit 0
else
    if [ $max_ops -gt 5500 ]; then
        echo -e "${RED}WARNING: Maximum operations exceed benchmark!${NC}"
    fi
    if [ $fail_count -gt 0 ]; then
        echo -e "${RED}WARNING: $fail_count sorts failed validation!${NC}"
    fi
    exit 1
fi
