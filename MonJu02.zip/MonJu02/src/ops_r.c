/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ops_r.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/02 21:18:43 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/02 21:20:02 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../libft/includes/libft.h"
#include <limits.h>
#include <stdlib.h>


	case OP_RA:
	{
		if (m->a->size < 2)
			return (0);
		node = m->a->top;
		m->a->top = m->a->top->next;
		m->a->top->prev = NULL;
		node->next = NULL;
		node->prev = m->a->bottom;
		m->a->bottom->next = node;
		m->a->bottom = node;
		ft_putstr_fd("ra\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RRA:
	{
		if (m->a->size < 2)
			return (0);
		node = m->a->bottom;
		m->a->bottom = m->a->bottom->prev;
		m->a->bottom->next = NULL;
		node->prev = NULL;
		node->next = m->a->top;
		m->a->top->prev = node;
		m->a->top = node;
		ft_putstr_fd("rra\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RB:
	{
		if (m->b->size < 2)
			return (0);
		node = m->b->top;
		m->b->top = m->b->top->next;
		m->b->top->prev = NULL;
		node->next = NULL;
		node->prev = m->b->bottom;
		m->b->bottom->next = node;
		m->b->bottom = node;
		ft_putstr_fd("rb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
    	case OP_RR:
	{
		ra_done = 0;
		rb_done = 0;
		if (m->a->size >= 2)
		{
			node = m->a->top;
			m->a->top = m->a->top->next;
			m->a->top->prev = NULL;
			node->next = NULL;
			node->prev = m->a->bottom;
			m->a->bottom->next = node;
			m->a->bottom = node;
			ra_done = 1;
		}
		if (m->b->size >= 2)
		{
			node = m->b->top;
			m->b->top = m->b->top->next;int	machine_execute(t_machine *m, t_operation op)
        }