#include "../libft/includes/libft.h"
#include "../include/machine.h"
#include "../include/sorting_machine.h"
#include <limits.h>

// Sort 3 elements using direct stack inspection
static void sort_three(t_machine* m) {
    if (!m || !m->a || m->a->size < 3)
        return;

    t_node* top = m->a->top;
    t_node* second = top->next;
    t_node* third = second->next;

    int a = top->value;
    int b = second->value;
    int c = third->value;

    if (a < b && b < c) return;          // [1,2,3]
    if (a < b && b > c && a < c) {       // [1,3,2]
        machine_execute(m, OP_SA);
        machine_execute(m, OP_RA);
    }
    else if (a > b && b < c && a < c) {  // [2,1,3]
        machine_execute(m, OP_SA);
    }
    else if (a < b && b > c && a > c) {  // [2,3,1]
        machine_execute(m, OP_RRA);
    }
    else if (a > b && b < c && a > c) {  // [3,1,2]
        machine_execute(m, OP_RA);
    }
    else if (a > b && b > c) {           // [3,2,1]
        machine_execute(m, OP_SA);
        machine_execute(m, OP_RRA);
    }
}

// Sort up to 5 elements
static void sort_five(t_machine* m) {
    // Push two smallest elements to B
    for (int i = 0; i < 2; i++) {
        int min_val = INT_MAX;
        size_t min_index = 0;
        size_t size = m->a->size;

        // Find min value and its position
        t_node* current = m->a->top;
        for (size_t j = 0; j < size; j++) {
            if (current->value < min_val) {
                min_val = current->value;
                min_index = j;
            }
            current = current->next;
        }

        // Bring min to top
        if (min_index <= size / 2) {
            for (size_t j = 0; j < min_index; j++) {
                machine_execute(m, OP_RA);
            }
        } else {
            for (size_t j = 0; j < size - min_index; j++) {
                machine_execute(m, OP_RRA);
            }
        }

        machine_execute(m, OP_PB);
    }

    // Sort remaining three
    sort_three(m);

    // Push back from B
    machine_execute(m, OP_PA);
    machine_execute(m, OP_PA);

    // Final rotation to correct order
    int min_value = INT_MAX;
    size_t size = m->a->size;
    size_t min_position = 0;
    t_node* current = m->a->top;

    for (size_t i = 0; i < size; i++) {
        if (current->value < min_value) {
            min_value = current->value;
            min_position = i;
        }
        current = current->next;
    }

    if (min_position <= size / 2) {
        for (size_t i = 0; i < min_position; i++) {
            machine_execute(m, OP_RA);
        }
    } else {
        for (size_t i = 0; i < size - min_position; i++) {
            machine_execute(m, OP_RRA);
        }
    }
}

// Helper to find minimal rotations for a value
static int find_min_rotations(t_stack *s, int index, int *dir) {
    int size = s->size;
    int up = index;
    int down = size - index;

    if (up <= down) {
        *dir = 0;  // ROTATE_UP
        return up;
    } else {
        *dir = 1;  // ROTATE_DOWN
        return down;
    }
}

// Find target position in A for a value
static int find_target_index(t_machine *m, int value) {
    t_node *current = m->a->top;
    int min_greater = INT_MAX;
    int min_index = -1;
    int min_all = INT_MAX;
    int min_all_index = -1;
    int i = 0;

    while (current) {
        // Track smallest element overall
        if (current->value < min_all) {
            min_all = current->value;
            min_all_index = i;
        }
        // Track smallest element greater than value
        if (current->value > value && current->value < min_greater) {
            min_greater = current->value;
            min_index = i;
        }
        current = current->next;
        i++;
    }
    return (min_index != -1) ? min_index : min_all_index;
}

// Find index of minimal value in stack
static int find_min_index(t_stack *s) {
    t_node *current = s->top;
    int min_index = 0;
    int min_val = current->value;
    int i = 0;

    while (current) {
        if (current->value < min_val) {
            min_val = current->value;
            min_index = i;
        }
        current = current->next;
        i++;
    }
    return min_index;
}

// Main sorting control function
void sorting_control(t_machine* m) {
    if (!m || !m->a) return;
    size_t size = m->a->size;
    if (size <= 1) return;

    // Handle small sizes directly
    if (size == 2) {
        if (m->a->top->value > m->a->top->next->value) {
            machine_execute(m, OP_SA);
        }
    }
    else if (size == 3) {
        sort_three(m);
    }
    else if (size <= 5) {
        sort_five(m);
    }
    else {
        // Phase 1: Push all but 3 elements to B
        while (m->a->size > 3) {
            machine_execute(m, OP_PB);
        }

        // Phase 2: Sort remaining 3 in A
        sort_three(m);

        // Phase 3: Smart push back from B to A
        while (m->b->size > 0) {
            int best_cost = INT_MAX;
            //int best_index;// = -1;
            int best_dir_a = 0, best_dir_b = 0;
            int best_rot_a = 0, best_rot_b = 0;
            t_node *current = m->b->top;
            int i = 0;

            // Find element with minimal rotation cost
            while (current) {
                int dir_a, dir_b;
                int cost_b = find_min_rotations(m->b, i, &dir_b);
                int target_idx = find_target_index(m, current->value);
                int cost_a = find_min_rotations(m->a, target_idx, &dir_a);
               // int total_cost = cost_a + cost_b;
               int total_cost = (dir_a == dis_b) ?
                    ft_max(cost_a, cost_b) :
                    cost_a + cost_b;

                // Deduct common operations if same direction
                if (dir_a == dir_b) {
                    total_cost -= (cost_a < cost_b) ? cost_a : cost_b;
                }

                if (total_cost < best_cost) {
                    best_cost = total_cost;
                    //best_index = i;
                    best_dir_a = dir_a;
                    best_dir_b = dir_b;
                    best_rot_a = cost_a;
                    best_rot_b = cost_b;
                }

                current = current->next;
                i++;
            }

            // Execute rotations
            if (best_dir_a == best_dir_b) {
                int common = (best_rot_a < best_rot_b) ? best_rot_a : best_rot_b;
                if (best_dir_a == 0) {
                    for (int j = 0; j < common; j++) machine_execute(m, OP_RR);
                } else {
                    for (int j = 0; j < common; j++) machine_execute(m, OP_RRR);
                }
                best_rot_a -= common;
                best_rot_b -= common;
            }

            // Execute remaining rotations
            for (int j = 0; j < best_rot_b; j++) {
                machine_execute(m, best_dir_b ? OP_RRB : OP_RB);
            }
            for (int j = 0; j < best_rot_a; j++) {
                machine_execute(m, best_dir_a ? OP_RRA : OP_RA);
            }

            // Push element to A
            machine_execute(m, OP_PA);
        }

        // Phase 4: Final rotation to min element
        int min_idx = find_min_index(m->a);
        int dir;
        int rotations = find_min_rotations(m->a, min_idx, &dir);
        for (int i = 0; i < rotations; i++) {
            machine_execute(m, dir ? OP_RRA : OP_RA);
        }
    }
}
