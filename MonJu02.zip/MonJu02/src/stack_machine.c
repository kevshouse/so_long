/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_machine.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/02 21:06:00 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/02 21:24:15 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../libft/includes/libft.h"
#include <limits.h>
#include <stdlib.h>

/* Static helper functions */
static t_stack	*stack_create(void)
{
	t_stack	*s;

	s = ft_calloc(1, sizeof(t_stack));
	if (s)
	{
		s->size = 0;
		s->top = NULL;
		s->bottom = NULL;
	}
	return (s);
}

static void	stack_add_back(t_stack *s, int value)
{
	t_node	*new;

	new = ft_calloc(1, sizeof(t_node));
	if (!new)
		return ;
	new->value = value;
	new->next = NULL;
	if (!s->top)
	{
		s->top = new;
		s->bottom = new;
		new->prev = NULL;
	}
	else
	{
		new->prev = s->bottom;
		s->bottom->next = new;
		s->bottom = new;
	}
	s->size++;
}

static void	free_stack(t_stack *s)
{
	t_node	*current;
	t_node	*next;

	if (!s)
		return ;
	current = s->top;
	while (current)
	{
		next = current->next;
		free(current);
		current = next;
	}
	free(s);
}

/* Helper function for duplicate checking */
static int	has_duplicates(int *arr, int count)
{
	for (int i = 0; i < count - 1; i++)
	{
		for (int j = i + 1; j < count; j++)
		{
			if (arr[i] == arr[j])
			{
				return (1);
			}
		}
	}
	return (0);
}

/* Public API implementation */
t_machine	*machine_init(int count, char **values)
{
	t_machine	*m;
	int			*numbers;
	long		num;

	m = ft_calloc(1, sizeof(t_machine));
	if (!m)
		return (NULL);
	m->a = stack_create();
	m->b = stack_create();
	if (!m->a || !m->b)
	{
		machine_free(m);
		return (NULL);
	}
	// Parse and validate all numbers first
	numbers = malloc(count * sizeof(int));
	if (!numbers)
	{
		machine_free(m);
		return (NULL);
	}
	for (int i = 0; i < count; i++)
	{
		if (!ft_isvalidnum(values[i]))
		{
			free(numbers);
			machine_free(m);
			return (NULL);
		}
		num = ft_atol(values[i]);
		if (num > INT_MAX || num < INT_MIN)
		{
			free(numbers);
			machine_free(m);
			return (NULL);
		}
		numbers[i] = (int)num;
	}
	// Check for duplicates
	if (has_duplicates(numbers, count))
	{
		free(numbers);
		machine_free(m);
		return (NULL);
	}
	// Add validated numbers to stack
	for (int i = 0; i < count; i++)
	{
		stack_add_back(m->a, numbers[i]);
	}
	free(numbers);
	return (m);
}

void	machine_free(t_machine *m)
{
	if (!m)
		return ;
	if (m->a)
		free_stack(m->a);
	if (m->b)
		free_stack(m->b);
	free(m);
}

int	machine_execute(t_machine *m, t_operation op)
{
	t_stack	*a;
	int		temp;
	t_stack	*b;
	int		temp;
	int		temp_a;
	int		temp_b;
	t_node	*node;
	t_node	*node;
	t_node	*node;
	t_node	*node;
	t_node	*node;
	t_node	*node;
	int		ra_done;
	int		rb_done;
	t_node	*node;
	t_node	*node;
	int		rra_done;
	int		rrb_done;
	t_node	*node;
	t_node	*node;

	if (!m)
		return (-1);
	switch (op)
	{
	case OP_SA:
	{
		a = m->a;
		if (a->size < 2)
			return (0);
		temp = a->top->value;
		a->top->value = a->top->next->value;
		a->top->next->value = temp;
		ft_putstr_fd("sa\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_SB:
	{
		b = m->b;
		if (b->size < 2)
			return (0);
		temp = b->top->value;
		b->top->value = b->top->next->value;
		b->top->next->value = temp;
		ft_putstr_fd("sb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);int	machine_execute(t_machine *m, t_operation op)
{
	t_stack	*a;
	int		temp;
	t_stack	*b;
	int		temp;
	int		temp_a;
	int		temp_b;
	t_node	*node;
	t_node	*node;
	t_node	*node;
	t_node	*node;
	t_node	*node;
	t_node	*node;
	int		ra_done;
	int		rb_done;
	t_node	*node;
	t_node	*node;
	int		rra_done;
	int		rrb_done;
	t_node	*node;
	t_node	*node;

	if (!m)
		return (-1);
	switch (op)
	{
	case OP_SA:
	{
		a = m->a;
		if (a->size < 2)
			return (0);
		temp = a->top->value;
		a->top->value = a->top->next->value;
		a->top->next->value = temp;
		ft_putstr_fd("sa\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_SB:
	{
		b = m->b;
		if (b->size < 2)
			return (0);
		temp = b->top->value;
		b->top->value = b->top->next->value;
		b->top->next->value = temp;
		ft_putstr_fd("sb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_SS:
	{
		// Execute both swaps
		if (m->a->size >= 2 && m->b->size >= 2)
		{
			temp_a = m->a->top->value;
			m->a->top->value = m->a->top->next->value;
			m->a->top->next->value = temp_a;
			temp_b = m->b->top->value;
			m->b->top->value = m->b->top->next->value;
			m->b->top->next->value = temp_b;
			ft_putstr_fd("ss\n", STDOUT_FILENO);
			m->op_count++;
		}
		return (0);
	}
	case OP_PA:
	{
		if (m->b->size == 0)
			return (0);
		node = m->b->top;
		m->b->top = m->b->top->next;
		if (m->b->top)
			m->b->top->prev = NULL;
		else
			m->b->bottom = NULL;
		m->b->size--;
		node->next = m->a->top;
		if (m->a->top)
			m->a->top->prev = node;
		else
			m->a->bottom = node;
		m->a->top = node;
		m->a->size++;
		ft_putstr_fd("pa\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_PB:
	{
		if (m->a->size == 0)
			return (0);
		node = m->a->top;
		m->a->top = m->a->top->next;
		if (m->a->top)
			m->a->top->prev = NULL;
		else
			m->a->bottom = NULL;
		m->a->size--;
		node->next = m->b->top;
		if (m->b->top)
			m->b->top->prev = node;
		else
			m->b->bottom = node;
		m->b->top = node;
		m->b->size++;
		ft_putstr_fd("pb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RA:
	{
		if (m->a->size < 2)
			return (0);
		node = m->a->top;
		m->a->top = m->a->top->next;
		m->a->top->prev = NULL;
		node->next = NULL;
		node->prev = m->a->bottom;
		m->a->bottom->next = node;
		m->a->bottom = node;
		ft_putstr_fd("ra\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RRA:
	{
		if (m->a->size < 2)
			return (0);
		node = m->a->bottom;
		m->a->bottom = m->a->bottom->prev;
		m->a->bottom->next = NULL;
		node->prev = NULL;
		node->next = m->a->top;
		m->a->top->prev = node;
		m->a->top = node;
		ft_putstr_fd("rra\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RB:
	{
		if (m->b->size < 2)
			return (0);
		node = m->b->top;
		m->b->top = m->b->top->next;
		m->b->top->prev = NULL;
		node->next = NULL;
		node->prev = m->b->bottom;
		m->b->bottom->next = node;
		m->b->bottom = node;
		ft_putstr_fd("rb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RRB:
	{
		if (m->b->size < 2)
			return (0);
		node = m->b->bottom;
		m->b->bottom = m->b->bottom->prev;
		m->b->bottom->next = NULL;
		node->prev = NULL;
		node->next = m->b->top;
		m->b->top->prev = node;
		m->b->top = node;
		ft_putstr_fd("rrb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RR:
	{
		ra_done = 0;
		rb_done = 0;
		if (m->a->size >= 2)
		{
			node = m->a->top;
			m->a->top = m->a->top->next;
			m->a->top->prev = NULL;
			node->next = NULL;
			node->prev = m->a->bottom;
			m->a->bottom->next = node;
			m->a->bottom = node;
			ra_done = 1;
		}
		if (m->b->size >= 2)
		{
			node = m->b->top;
			m->b->top = m->b->top->next;int	machine_execute(t_machine *m, t_operation op)
{
	t_stack	*a;
	int		temp;
	t_stack	*b;
	int		temp;
	int		temp_a;
	int		temp_b;
	t_node	*node;
	t_node	*node;
	t_node	*node;
	t_node	*node;
	t_node	*node;
	t_node	*node;
	int		ra_done;
	int		rb_done;
	t_node	*node;
	t_node	*node;
	int		rra_done;
	int		rrb_done;
	t_node	*node;
	t_node	*node;

	if (!m)
		return (-1);
	switch (op)
	{
	case OP_SA:
	{
		a = m->a;
		if (a->size < 2)
			return (0);
		temp = a->top->value;
		a->top->value = a->top->next->value;
		a->top->next->value = temp;
		ft_putstr_fd("sa\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_SB:
	{
		b = m->b;
		if (b->size < 2)
			return (0);
		temp = b->top->value;
		b->top->value = b->top->next->value;
		b->top->next->value = temp;
		ft_putstr_fd("sb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_SS:
	{
		// Execute both swaps
		if (m->a->size >= 2 && m->b->size >= 2)
		{
			temp_a = m->a->top->value;
			m->a->top->value = m->a->top->next->value;
			m->a->top->next->value = temp_a;
			temp_b = m->b->top->value;
			m->b->top->value = m->b->top->next->value;
			m->b->top->next->value = temp_b;
			ft_putstr_fd("ss\n", STDOUT_FILENO);
			m->op_count++;
		}
		return (0);
	}
	case OP_PA:
	{
		if (m->b->size == 0)
			return (0);
		node = m->b->top;
		m->b->top = m->b->top->next;
		if (m->b->top)
			m->b->top->prev = NULL;
		else
			m->b->bottom = NULL;
		m->b->size--;
		node->next = m->a->top;
		if (m->a->top)
			m->a->top->prev = node;
		else
			m->a->bottom = node;
		m->a->top = node;
		m->a->size++;
		ft_putstr_fd("pa\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_PB:
	{
		if (m->a->size == 0)
			return (0);
		node = m->a->top;
		m->a->top = m->a->top->next;
		if (m->a->top)
			m->a->top->prev = NULL;
		else
			m->a->bottom = NULL;
		m->a->size--;
		node->next = m->b->top;
		if (m->b->top)
			m->b->top->prev = node;
		else
			m->b->bottom = node;
		m->b->top = node;
		m->b->size++;
		ft_putstr_fd("pb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RA:
	{
		if (m->a->size < 2)
			return (0);
		node = m->a->top;
		m->a->top = m->a->top->next;
		m->a->top->prev = NULL;
		node->next = NULL;
		node->prev = m->a->bottom;
		m->a->bottom->next = node;
		m->a->bottom = node;
		ft_putstr_fd("ra\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RRA:
	{
		if (m->a->size < 2)
			return (0);
		node = m->a->bottom;
		m->a->bottom = m->a->bottom->prev;
		m->a->bottom->next = NULL;
		node->prev = NULL;
		node->next = m->a->top;
		m->a->top->prev = node;
		m->a->top = node;
		ft_putstr_fd("rra\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RB:
	{
		if (m->b->size < 2)
			return (0);
		node = m->b->top;
		m->b->top = m->b->top->next;
		m->b->top->prev = NULL;
		node->next = NULL;
		node->prev = m->b->bottom;
		m->b->bottom->next = node;
		m->b->bottom = node;
		ft_putstr_fd("rb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RRB:
	{
		if (m->b->size < 2)
			return (0);
		node = m->b->bottom;
		m->b->bottom = m->b->bottom->prev;
		m->b->bottom->next = NULL;
		node->prev = NULL;
		node->next = m->b->top;
		m->b->top->prev = node;
		m->b->top = node;
		ft_putstr_fd("rrb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RR:
	{
		ra_done = 0;
		rb_done = 0;
		if (m->a->size >= 2)
		{
			node = m->a->top;
			m->a->top = m->a->top->next;
			m->a->top->prev = NULL;
			node->next = NULL;
			node->prev = m->a->bottom;
			m->a->bottom->next = node;
			m->a->bottom = node;
			ra_done = 1;
		}
		if (m->b->size >= 2)
		{
			node = m->b->top;
			m->b->top = m->b->top->next;
			m->b->top->prev = NULL;
			node->next = NULL;
			node->prev = m->b->bottom;
			m->b->bottom->next = node;
			m->b->bottom = node;
			rb_done = 1;
		}
		if (ra_done || rb_done)
		{
			if (ra_done && rb_done)
			{
				ft_putstr_fd("rr\n", STDOUT_FILENO);
			}
			else if (ra_done)
			{
				ft_putstr_fd("ra\n", STDOUT_FILENO);
			}
			else if (rb_done)
			{
				ft_putstr_fd("rb\n", STDOUT_FILENO);
			}
			m->op_count++;
		}
		return (0);
	}
	case OP_RRR:
	{
		rra_done = 0;
		rrb_done = 0;
		if (m->a->size >= 2)
		{
			node = m->a->bottom;
			m->a->bottom = m->a->bottom->prev;
			m->a->bottom->next = NULL;
			node->prev = NULL;
			node->next = m->a->top;
			m->a->top->prev = node;
			m->a->top = node;
			rra_done = 1;
		}
		if (m->b->size >= 2)
		{
			node = m->b->bottom;
			m->b->bottom = m->b->bottom->prev;
			m->b->bottom->next = NULL;
			node->prev = NULL;
			node->next = m->b->top;
			m->b->top->prev = node;
			m->b->top = node;
			rrb_done = 1;
		}
		if (rra_done || rrb_done)
		{
			if (rra_done && rrb_done)
			{
				ft_putstr_fd("rrr\n", STDOUT_FILENO);
			}
			else if (rra_done)
			{
				ft_putstr_fd("rra\n", STDOUT_FILENO);
			}
			else if (rrb_done)
			{
				ft_putstr_fd("rrb\n", STDOUT_FILENO);
			}
			m->op_count++;
		}
		return (0);
	}
	default:
		return (0);
	}
}
			m->b->top->prev = NULL;
			node->next = NULL;
			node->prev = m->b->bottom;
			m->b->bottom->next = node;
			m->b->bottom = node;
			rb_done = 1;
		}
		if (ra_done || rb_done)
		{
			if (ra_done && rb_done)
			{
				ft_putstr_fd("rr\n", STDOUT_FILENO);
			}
			else if (ra_done)
			{
				ft_putstr_fd("ra\n", STDOUT_FILENO);
			}
			else if (rb_done)
			{
				ft_putstr_fd("rb\n", STDOUT_FILENO);
			}
			m->op_count++;
		}
		return (0);
	}
	case OP_RRR:
	{
		rra_done = 0;
		rrb_done = 0;
		if (m->a->size >= 2)
		{
			node = m->a->bottom;
			m->a->bottom = m->a->bottom->prev;
			m->a->bottom->next = NULL;
			node->prev = NULL;
			node->next = m->a->top;
			m->a->top->prev = node;
			m->a->top = node;
			rra_done = 1;
		}
		if (m->b->size >= 2)
		{
			node = m->b->bottom;
			m->b->bottom = m->b->bottom->prev;
			m->b->bottom->next = NULL;
			node->prev = NULL;
			node->next = m->b->top;
			m->b->top->prev = node;
			m->b->top = node;
			rrb_done = 1;
		}
		if (rra_done || rrb_done)
		{
			if (rra_done && rrb_done)
			{
				ft_putstr_fd("rrr\n", STDOUT_FILENO);
			}
			else if (rra_done)
			{
				ft_putstr_fd("rra\n", STDOUT_FILENO);
			}
			else if (rrb_done)
			{
				ft_putstr_fd("rrb\n", STDOUT_FILENO);
			}
			m->op_count++;
		}
		return (0);
	}
	default:
		return (0);
	}
}
	}
	case OP_SS:
	{
		// Execute both swaps
		if (m->a->size >= 2 && m->b->size >= 2)
		{
			temp_a = m->a->top->value;
			m->a->top->value = m->a->top->next->value;
			m->a->top->next->value = temp_a;
			temp_b = m->b->top->value;
			m->b->top->value = m->b->top->next->value;
			m->b->top->next->value = temp_b;
			ft_putstr_fd("ss\n", STDOUT_FILENO);
			m->op_count++;
		}
		return (0);
	}
	case OP_PA:
	{
		if (m->b->size == 0)
			return (0);
		node = m->b->top;
		m->b->top = m->b->top->next;
		if (m->b->top)
			m->b->top->prev = NULL;
		else
			m->b->bottom = NULL;
		m->b->size--;
		node->next = m->a->top;
		if (m->a->top)
			m->a->top->prev = node;
		else
			m->a->bottom = node;
		m->a->top = node;
		m->a->size++;
		ft_putstr_fd("pa\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_PB:
	{
		if (m->a->size == 0)
			return (0);
		node = m->a->top;
		m->a->top = m->a->top->next;
		if (m->a->top)
			m->a->top->prev = NULL;
		else
			m->a->bottom = NULL;
		m->a->size--;
		node->next = m->b->top;
		if (m->b->top)
			m->b->top->prev = node;
		else
			m->b->bottom = node;
		m->b->top = node;
		m->b->size++;
		ft_putstr_fd("pb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RA:
	{
		if (m->a->size < 2)
			return (0);
		node = m->a->top;
		m->a->top = m->a->top->next;
		m->a->top->prev = NULL;
		node->next = NULL;
		node->prev = m->a->bottom;
		m->a->bottom->next = node;
		m->a->bottom = node;
		ft_putstr_fd("ra\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RRA:
	{
		if (m->a->size < 2)
			return (0);
		node = m->a->bottom;
		m->a->bottom = m->a->bottom->prev;
		m->a->bottom->next = NULL;
		node->prev = NULL;
		node->next = m->a->top;
		m->a->top->prev = node;
		m->a->top = node;
		ft_putstr_fd("rra\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RB:
	{
		if (m->b->size < 2)
			return (0);
		node = m->b->top;
		m->b->top = m->b->top->next;
		m->b->top->prev = NULL;
		node->next = NULL;
		node->prev = m->b->bottom;
		m->b->bottom->next = node;
		m->b->bottom = node;
		ft_putstr_fd("rb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RRB:
	{
		if (m->b->size < 2)
			return (0);
		node = m->b->bottom;
		m->b->bottom = m->b->bottom->prev;
		m->b->bottom->next = NULL;
		node->prev = NULL;
		node->next = m->b->top;
		m->b->top->prev = node;
		m->b->top = node;
		ft_putstr_fd("rrb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_RR:
	{
		ra_done = 0;
		rb_done = 0;
		if (m->a->size >= 2)
		{
			node = m->a->top;
			m->a->top = m->a->top->next;
			m->a->top->prev = NULL;
			node->next = NULL;
			node->prev = m->a->bottom;
			m->a->bottom->next = node;
			m->a->bottom = node;
			ra_done = 1;
		}
		if (m->b->size >= 2)
		{
			node = m->b->top;
			m->b->top = m->b->top->next;
			m->b->top->prev = NULL;
			node->next = NULL;
			node->prev = m->b->bottom;
			m->b->bottom->next = node;
			m->b->bottom = node;
			rb_done = 1;
		}
		if (ra_done || rb_done)
		{
			if (ra_done && rb_done)
			{
				ft_putstr_fd("rr\n", STDOUT_FILENO);
			}
			else if (ra_done)
			{
				ft_putstr_fd("ra\n", STDOUT_FILENO);
			}
			else if (rb_done)
			{
				ft_putstr_fd("rb\n", STDOUT_FILENO);
			}
			m->op_count++;
		}
		return (0);
	}
	case OP_RRR:
	{
		rra_done = 0;
		rrb_done = 0;
		if (m->a->size >= 2)
		{
			node = m->a->bottom;
			m->a->bottom = m->a->bottom->prev;
			m->a->bottom->next = NULL;
			node->prev = NULL;
			node->next = m->a->top;
			m->a->top->prev = node;
			m->a->top = node;
			rra_done = 1;
		}
		if (m->b->size >= 2)
		{
			node = m->b->bottom;
			m->b->bottom = m->b->bottom->prev;
			m->b->bottom->next = NULL;
			node->prev = NULL;
			node->next = m->b->top;
			m->b->top->prev = node;
			m->b->top = node;
			rrb_done = 1;
		}
		if (rra_done || rrb_done)
		{
			if (rra_done && rrb_done)
			{
				ft_putstr_fd("rrr\n", STDOUT_FILENO);
			}
			else if (rra_done)
			{
				ft_putstr_fd("rra\n", STDOUT_FILENO);
			}
			else if (rrb_done)
			{
				ft_putstr_fd("rrb\n", STDOUT_FILENO);
			}
			m->op_count++;
		}
		return (0);
	}
	default:
		return (0);
	}
}

/* Stack inspection */
int	machine_top_value(const t_machine *m, t_stack_id stack_id)
{
	const t_stack	*s = (stack_id == STACK_A) ? m->a : m->b;

	if (!s || !s->top)
		return (0);
	return s->top->value;
}

size_t	machine_stack_size(const t_machine *m, t_stack_id stack_id)
{
	const t_stack	*s = (stack_id == STACK_A) ? m->a : m->b;

	if (!s)
		return 0;
	return s->size;
}

size_t	machine_op_count(const t_machine *m)
{
	if (!m)
		return 0;
	return m->op_count;
}

t_bool	machine_verify_stack_links(const t_machine *m, t_stack_id stack_id)
{
	const t_stack	*s = (stack_id == STACK_A) ? m->a : m->b;
	t_node			*current;
	size_t			count;

	if (!s || s->size == 0)
		return FT_TRUE;
	if (s->top->prev != NULL)
		return FT_FALSE;
	if (s->bottom->next != NULL)
		return FT_FALSE;
	if (s->size == 1 && s->top != s->bottom)
		return FT_FALSE;
	current = s->top;
	count = 1;
	while (current->next)
	{
		if (current->next->prev != current)
			return FT_FALSE;
		current = current->next;
		count++;
	}
	if (current != s->bottom)
		return FT_FALSE;
	if (count != s->size)
		return FT_FALSE;
	return FT_TRUE;
}

t_bool	machine_is_sorted(const t_machine *m, t_stack_id stack_id)
{
	const t_stack	*s = (stack_id == STACK_A) ? m->a : m->b;
	t_node			*current;

	if (!s || s->size < 2)
		return FT_TRUE;
	current = s->top;
	while (current->next)
	{
		if (current->value > current->next->value)
			return FT_FALSE;
		current = current->next;
	}
	return FT_TRUE;
}

void	machine_print_stack(const t_machine *m, t_stack_id stack_id)
{
	const t_stack	*s = (stack_id == STACK_A) ? m->a : m->b;
	t_node			*current;

	if (!s)
	{
		ft_printf("(null)\n");
		return ;
	}
	ft_printf("[");
	current = s->top;
	while (current)
	{
		ft_printf("%d", current->value);
		if (current->next)
			ft_printf(", ");
		current = current->next;
	}
	ft_printf("]\n");
}

t_node	*machine_get_top_node(const t_machine *m, t_stack_id stack_id)
{
	t_stack	*s;

	if (!m)
		return NULL;
	s = (stack_id == STACK_A) ? m->a : m->b;
	return s ? s->top : NULL;
}

t_node	*machine_get_next_node(const t_node *node)
{
	return node ? node->next : NULL;
}

int	machine_get_node_value(const t_node *node)
{
	return node ? node->value : 0;
}
