#include "../include/machine.h"
#include "../libft/includes/libft.h"
#include <limits.h>
#include <stdio.h>

// Helper function for simple integer comparison
static int compare_ints(const void *a, const void *b)
{
    return (*(int *)a - *(int *)b);
}

/* Static helper functions */
static t_stack* stack_create(void)
{
    t_stack* s = ft_calloc(1, sizeof(t_stack));
    if (s)
    {
        s->size = 0;
        s->top = NULL;
        s->bottom = NULL;
    }
    return s;
}

static void stack_add_back(t_stack* s, int value)
{
    t_node* new = ft_calloc(1, sizeof(t_node));
    if (!new)
        return;

    new->value = value;
    new->next = NULL;

    if (!s->top)
    {
        s->top = new;
        s->bottom = new;
        new->prev = NULL;
    }
    else
    {
        new->prev = s->bottom;
        s->bottom->next = new;
        s->bottom = new;
    }
    s->size++;
}

static void free_stack(t_stack* s)
{
    if (!s)
        return;

    t_node* current = s->top;
    while (current)
    {
        t_node* next = current->next;
        free(current);
        current = next;
    }
    free(s);
}

/* Public API implementation */
t_machine* machine_init(int count, char** values)
{
    t_machine* m = ft_calloc(1, sizeof(t_machine));
    if (!m)
        return NULL;

    m->a = stack_create();
    m->b = stack_create();
    if (!m->a || !m->b)
    {
        machine_free(m);
        return NULL;
    }

    for (int i = 0; i < count; i++)
    {
        // Validate number format
        if (!ft_isvalidnum(values[i]))
        {
            machine_free(m);
            return NULL;
        }

        // Convert to long and check range
        long num = ft_atol(values[i]);
        if (num > INT_MAX || num < INT_MIN)
        {
            machine_free(m);
            return NULL;
        }

        // Check for duplicates
        for (int j = 0; j < i; j++)
        {
            long prev_num = ft_atol(values[j]);
            if (prev_num == num)
            {
                machine_free(m);
                return NULL;
            }
        }

        stack_add_back(m->a, (int)num);
    }
    return m;
}

void machine_free(t_machine* m)
{
    if (!m)
        return;

    if (m->a)
        free_stack(m->a);
    if (m->b)
        free_stack(m->b);
    free(m);
}

int machine_execute(t_machine* m, t_operation op)
{
    if (!m)
        return -1;

    switch (op) {
        case OP_SA: {
            t_stack *a = m->a;
            if (a->size < 2)
                return 0;

            // Swap the top two elements
            int temp = a->top->value;
            a->top->value = a->top->next->value;
            a->top->next->value = temp;
            m->op_count++;
            return 0;
        }
        case OP_PA: {
            if (m->b->size == 0)
                return 0;

            // Pop from B
            t_node* node = m->b->top;
            m->b->top = m->b->top->next;
            if (m->b->top)
                m->b->top->prev = NULL;
            else
                m->b->bottom = NULL;
            m->b->size--;

            // Push to A
            node->next = m->a->top;
            if (m->a->top)
                m->a->top->prev = node;
            else
                m->a->bottom = node;
            m->a->top = node;
            m->a->size++;

            m->op_count++;
            return 0;
        }
        case OP_PB: {
            if (m->a->size == 0)
                return 0;

            // Pop from A
            t_node* node = m->a->top;
            m->a->top = m->a->top->next;
            if (m->a->top)
                m->a->top->prev = NULL;
            else
                m->a->bottom = NULL;
            m->a->size--;

            // Push to B
            node->next = m->b->top;
            if (m->b->top)
                m->b->top->prev = node;
            else
                m->b->bottom = node;
            m->b->top = node;
            m->b->size++;

            m->op_count++;
            return 0;
        }
        case OP_RA: {
            if (m->a->size < 2)
                return 0;

            t_node* node = m->a->top;
            m->a->top = m->a->top->next;
            m->a->top->prev = NULL;
            node->next = NULL;
            node->prev = m->a->bottom;
            m->a->bottom->next = node;
            m->a->bottom = node;
            m->op_count++;
            return 0;
        }
        case OP_RRA: {
            if (m->a->size < 2)
                return 0;

            t_node* node = m->a->bottom;
            m->a->bottom = m->a->bottom->prev;
            m->a->bottom->next = NULL;
            node->prev = NULL;
            node->next = m->a->top;
            m->a->top->prev = node;
            m->a->top = node;
            m->op_count++;
            return 0;
        }
        // Add to machine_execute in stack_machine.c
        case OP_RB: {
            if (m->b->size < 2) return 0;
            t_node* node = m->b->top;
            m->b->top = m->b->top->next;
            m->b->top->prev = NULL;
            node->next = NULL;
            node->prev = m->b->bottom;
            m->b->bottom->next = node;
            m->b->bottom = node;
            m->op_count++;
            return 0;
        }
        case OP_RRB: {
            if (m->b->size < 2) return 0;
            t_node* node = m->b->bottom;
            m->b->bottom = m->b->bottom->prev;
            m->b->bottom->next = NULL;
            node->prev = NULL;
            node->next = m->b->top;
            m->b->top->prev = node;
            m->b->top = node;
            m->op_count++;
            return 0;
        }
        case OP_RR: {
            if (machine_execute(m, OP_RA) == -1) return -1;
            if (machine_execute(m, OP_RB) == -1) return -1;
            return 0;
        }
        case OP_RRR: {
            if (machine_execute(m, OP_RRA) == -1) return -1;
            if (machine_execute(m, OP_RRB) == -1) return -1;
            return 0;
        }
        default:
            return 0;
    }
}

/* Stack inspection */
int machine_top_value(const t_machine* m, t_stack_id stack_id)
{
    const t_stack* s = (stack_id == STACK_A) ? m->a : m->b;
    if (!s || !s->top)
        return 0;
    return s->top->value;
}

size_t machine_stack_size(const t_machine* m, t_stack_id stack_id)
{
    const t_stack* s = (stack_id == STACK_A) ? m->a : m->b;
    if (!s)
        return 0;
    return s->size;
}

size_t machine_op_count(const t_machine* m)
{
    if (!m) return 0;
    return m->op_count;
}

t_bool machine_verify_stack_links(const t_machine* m, t_stack_id stack_id)
{
    const t_stack* s = (stack_id == STACK_A) ? m->a : m->b;
    if (!s || s->size == 0)
        return FT_TRUE;

    // Check top and bottom pointers
    if (s->top->prev != NULL) return FT_FALSE;
    if (s->bottom->next != NULL) return FT_FALSE;
    if (s->size == 1 && s->top != s->bottom) return FT_FALSE;

    t_node *current = s->top;
    size_t count = 1;

    // Traverse forward
    while (current->next) {
        if (current->next->prev != current)
            return FT_FALSE;
        current = current->next;
        count++;
    }

    // Verify we reached the bottom
    if (current != s->bottom)
        return FT_FALSE;

    // Verify node count matches size
    if (count != s->size)
        return FT_FALSE;

    return FT_TRUE;
}

t_bool machine_is_sorted(const t_machine* m, t_stack_id stack_id)
{
    const t_stack* s = (stack_id == STACK_A) ? m->a : m->b;
    if (!s || s->size < 2)
        return FT_TRUE;

    t_node* current = s->top;
    while (current->next)
    {
        if (current->value > current->next->value)
            return FT_FALSE;
        current = current->next;
    }
    return FT_TRUE;
}

void machine_print_stack(const t_machine* m, t_stack_id stack_id)
{
    const t_stack* s = (stack_id == STACK_A) ? m->a : m->b;
    if (!s) {
        printf("(null)\n");
        return;
    }

    printf("[");
    t_node* current = s->top;
    while (current) {
        printf("%d", current->value);
        if (current->next) printf(", ");
        current = current->next;
    }
    printf("]\n");
}

// Helper functions for direct stack access
t_node* machine_get_top_node(const t_machine* m, t_stack_id stack_id) {
    if (!m) return NULL;
    t_stack* s = (stack_id == STACK_A) ? m->a : m->b;
    return s ? s->top : NULL;
}

t_node* machine_get_next_node(const t_node* node) {
    return node ? node->next : NULL;
}

int machine_get_node_value(const t_node* node) {
    return node ? node->value : 0;
}
