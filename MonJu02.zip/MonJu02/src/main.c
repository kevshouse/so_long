/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/02 21:06:15 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/02 21:09:32 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../include/sorting_machine.h"
#include "../libft/includes/libft.h"

int	main(int argc, char **argv)
{
	t_machine	*m;

	if (argc < 2)
		return (1);
	m = machine_init(argc - 1, argv + 1);
	if (!m)
	{
		ft_putstr_fd("Error\n", STDERR_FILENO);
		return (1);
	}
	sorting_control(m);
	machine_free(m);
	return (0);
}
