#include "../include/machine.h"
#include "../include/sorting_machine.h"
#include <stdlib.h>
#include <limits.h>

// Sort 3 elements using direct stack inspection
static void sort_three(t_machine* m) {
    if (!m || !m->a || m->a->size < 3)
        return;

    t_node* top = m->a->top;
    t_node* second = top->next;
    t_node* third = second->next;

    int a = top->value;
    int b = second->value;
    int c = third->value;

    if (a < b && b < c) return;
    if (a < b && b > c && a < c) {
        machine_execute(m, OP_SA);
        machine_execute(m, OP_RA);
    }
    else if (a > b && b < c && a < c) {
        machine_execute(m, OP_SA);
    }
    else if (a < b && b > c && a > c) {
        machine_execute(m, OP_RRA);
    }
    else if (a > b && b < c && a > c) {
        machine_execute(m, OP_RA);
    }
    else if (a > b && b > c) {
        machine_execute(m, OP_SA);
        machine_execute(m, OP_RRA);
    }
}

// Sort up to 5 elements
static void sort_five(t_machine* m) {
    for (int i = 0; i < 2; i++) {
        int min_val = INT_MAX;
        size_t min_index = 0;
        size_t size = m->a->size;

        t_node* current = m->a->top;
        for (size_t j = 0; j < size; j++) {
            if (current->value < min_val) {
                min_val = current->value;
                min_index = j;
            }
            current = current->next;
        }

        if (min_index <= size / 2) {
            for (size_t j = 0; j < min_index; j++) {
                machine_execute(m, OP_RA);
            }
        } else {
            for (size_t j = 0; j < size - min_index; j++) {
                machine_execute(m, OP_RRA);
            }
        }

        machine_execute(m, OP_PB);
    }

    sort_three(m);

    machine_execute(m, OP_PA);
    machine_execute(m, OP_PA);

    int min_value = INT_MAX;
    size_t size = m->a->size;
    size_t min_position = 0;
    t_node* current = m->a->top;

    for (size_t i = 0; i < size; i++) {
        if (current->value < min_value) {
            min_value = current->value;
            min_position = i;
        }
        current = current->next;
    }

    if (min_position <= size / 2) {
        for (size_t i = 0; i < min_position; i++) {
            machine_execute(m, OP_RA);
        }
    } else {
        for (size_t i = 0; i < size - min_position; i++) {
            machine_execute(m, OP_RRA);
        }
    }
}

// Helper to create sorted array from stack
static int* create_sorted_arr(t_stack *s) {
    if (!s || !s->top) return NULL;

    int *arr = malloc(s->size * sizeof(int));
    if (!arr) return NULL;

    t_node *current = s->top;
    for (size_t i = 0; i < s->size; i++) {
        arr[i] = current->value;
        current = current->next;
    }

    // Insertion sort
    for (size_t i = 1; i < s->size; i++) {
        int key = arr[i];
        size_t j = i;

        while (j > 0 && arr[j - 1] > key) {
            arr[j] = arr[j - 1];
            j--;
        }
        arr[j] = key;
    }
    return arr;
}

// Find index of max value in stack
static int find_max_index(t_stack *s) {
    if (!s || !s->top) return -1;

    int max_index = 0;
    int max_val = s->top->value;
    t_node *current = s->top->next;

    for (int i = 1; current; i++) {
        if (current->value > max_val) {
            max_val = current->value;
            max_index = i;
        }
        current = current->next;
    }
    return max_index;
}

// Rotate max value to top of stack B
static void rotate_max_to_top(t_machine *m) {
    int max_index = find_max_index(m->b);
    if (max_index == -1) return;

    size_t size = m->b->size;
    if (max_index <= (int)size / 2) {
        for (int i = 0; i < max_index; i++) {
            machine_execute(m, OP_RB);
        }
    } else {
        for (size_t i = 0; i < size - max_index; i++) {
            machine_execute(m, OP_RRB);
        }
    }
}

// Chunk-based sorting for large stacks
static void chunk_sort(t_machine *m) {
    size_t size = m->a->size;
    int *sorted_arr = create_sorted_arr(m->a);
    if (!sorted_arr) return;

    // Determine chunk count based on input size
    int chunk_count;
    if (size <= 100) chunk_count = 5;
    else if (size <= 500) chunk_count = 11;
    else chunk_count = 15;

    int chunk_size = size / chunk_count;
    int chunk_start = 0;

    while (chunk_start < (int)size) {
        int chunk_end = chunk_start + chunk_size;
        if (chunk_end >= (int)size) chunk_end = size - 1;

        int median = sorted_arr[(chunk_start + chunk_end) / 2];
        int count_in_chunk = 0;
        int target_count = chunk_end - chunk_start + 1;

        while (count_in_chunk < target_count) {
            int top = machine_top_value(m, STACK_A);

            if (top >= sorted_arr[chunk_start] && top <= sorted_arr[chunk_end]) {
                machine_execute(m, OP_PB);
                count_in_chunk++;

                if (top < median && machine_stack_size(m, STACK_B) > 1) {
                    machine_execute(m, OP_RB);
                }
            } else {
                machine_execute(m, OP_RA);
            }
        }
        chunk_start = chunk_end + 1;
    }
    free(sorted_arr);

    // Push back to A in sorted order
    while (machine_stack_size(m, STACK_B) > 0) {
        rotate_max_to_top(m);
        machine_execute(m, OP_PA);
    }
}

// Main sorting control
void sorting_control(t_machine* m) {
    if (!m || !m->a) return;
    size_t size = m->a->size;
    if (size <= 1) return;

    if (size == 2) {
        if (m->a->top->value > m->a->top->next->value) {
            machine_execute(m, OP_SA);
        }
    }
    else if (size == 3) {
        sort_three(m);
    }
    else if (size <= 5) {
        sort_five(m);
    }
    else {
        chunk_sort(m);
    }
}
