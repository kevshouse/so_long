/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ops_s.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/02 21:22:17 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/02 21:22:38 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

case OP_SA:
	{
		a = m->a;
		if (a->size < 2)
			return (0);
		temp = a->top->value;
		a->top->value = a->top->next->value;
		a->top->next->value = temp;
		ft_putstr_fd("sa\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_SB:
	{
		b = m->b;
		if (b->size < 2)
			return (0);
		temp = b->top->value;
		b->top->value = b->top->next->value;
		b->top->next->value = temp;
		ft_putstr_fd("sb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_SS:
	{
		// Execute both swaps
		if (m->a->size >= 2 && m->b->size >= 2)
		{
			temp_a = m->a->top->value;
			m->a->top->value = m->a->top->next->value;
			m->a->top->next->value = temp_a;
			temp_b = m->b->top->value;
			m->b->top->value = m->b->top->next->value;
			m->b->top->next->value = temp_b;
			ft_putstr_fd("ss\n", STDOUT_FILENO);
			m->op_count++;
		}
		return (0);
	}