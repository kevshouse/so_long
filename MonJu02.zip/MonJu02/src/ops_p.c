/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ops_p.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kevin-anderson <kevin-anderson@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/02 21:16:17 by kevin-ander       #+#    #+#             */
/*   Updated: 2025/06/02 21:17:52 by kevin-ander      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/machine.h"
#include "../libft/includes/libft.h"
#include <limits.h>
#include <stdlib.h>

case OP_PA:
	{
		if (m->b->size == 0)
			return (0);
		node = m->b->top;
		m->b->top = m->b->top->next;
		if (m->b->top)
			m->b->top->prev = NULL;
		else
			m->b->bottom = NULL;
		m->b->size--;
		node->next = m->a->top;
		if (m->a->top)
			m->a->top->prev = node;
		else
			m->a->bottom = node;
		m->a->top = node;
		m->a->size++;
		ft_putstr_fd("pa\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}
	case OP_PB:
	{
		if (m->a->size == 0)
			return (0);
		node = m->a->top;
		m->a->top = m->a->top->next;
		if (m->a->top)
			m->a->top->prev = NULL;
		else
			m->a->bottom = NULL;
		m->a->size--;
		node->next = m->b->top;
		if (m->b->top)
			m->b->top->prev = node;
		else
			m->b->bottom = node;
		m->b->top = node;
		m->b->size++;
		ft_putstr_fd("pb\n", STDOUT_FILENO);
		m->op_count++;
		return (0);
	}