#include "../include/machine.h"

static int has_duplicates(int *arr, int count)
{
	int i;
	int j;

	i = 0;
	while(i < count - 1)
	{
		j = i + 1;
		while(j < count)
		{
			if(arr[i] == arr[j])
				return (1);
			j++;
		}
		i++;
	}
	return (0);
}

t_bool ft_isvalidnum(const char *str)
{
	if(!str || !*str)
		return (FT_FALSE);
	if(*str == '-' || *str == '+')
		str++;
	while(*str)
	{
		if(!ft_isdigit(*str))
			return (FT_FALSE);
		str++;
	}
	return (FT_TRUE);
}

t_bool ft_issafe(const char *str)
{
	long num;
	int  sign;

	sign = 1;
	num  = 0;
	if(*str == '-' || *str == '+')
	{
		if(*str == '-')
			sign = -1;
		str++;
	}
	while(*str >= '0' && *str <= '9')
	{
		num = num * 10 + (*str - '0');
		if((sign == 1 && num > INT_MAX) ||
		   (sign == -1 && num > (long)INT_MAX + 1))
			return (FT_FALSE);
		str++;
	}
	return (FT_TRUE);
}
