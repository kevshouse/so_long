#include "../include/machine.h"

static void rotate_stack(t_stack *s)
{
	t_node *node;

	if(s->size < 2)
		return;
	node            = s->top;
	s->top          = s->top->next;
	s->top->prev    = NULL;
	node->next      = NULL;
	node->prev      = s->bottom;
	s->bottom->next = node;
	s->bottom       = node;
}

void do_ra(t_machine *m)
{
	if(m->a->size < 2)
		return;
	rotate_stack(m->a);
	ft_putstr_fd("ra\n", STDOUT_FILENO);
	m->op_count++;
}

void do_rb(t_machine *m)
{
	if(m->b->size < 2)
		return;
	rotate_stack(m->b);
	ft_putstr_fd("rb\n", STDOUT_FILENO);
	m->op_count++;
}

void do_rr(t_machine *m)
{
	int ra_done;
	int rb_done;

	ra_done = 0;
	rb_done = 0;
	if(m->a->size >= 2)
	{
		rotate_stack(m->a);
		ra_done = 1;
	}
	if(m->b->size >= 2)
	{
		rotate_stack(m->b);
		rb_done = 1;
	}
	if(ra_done || rb_done)
	{
		if(ra_done && rb_done)
			ft_putstr_fd("rr\n", STDOUT_FILENO);
		else if(ra_done)
			ft_putstr_fd("ra\n", STDOUT_FILENO);
		else
			ft_putstr_fd("rb\n", STDOUT_FILENO);
		m->op_count++;
	}
}
